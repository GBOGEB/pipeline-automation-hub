"""Unit checks for the title taxonomy: python -m unittest test_taxonomy"""
import unittest

import taxonomy as T

V = T.Vocabulary()


def classify(title, kind="issue", **extra):
    row = dict({"repo": "r", "kind": kind, "number": 1, "title": title, "labels": []}, **extra)
    T.classify_all([row], V)
    return row


class ParseTests(unittest.TestCase):
    def test_compound_scope_with_pulse_qualifier(self):
        row = classify("fix(jade devops N12): census fails closed when blobs are missing", "pr")
        self.assertEqual(row["_cls"]["type"], "fix")
        self.assertEqual(row["_cls"]["scopes"], ["jade-devops"])
        self.assertEqual([q["token"] for q in row["_parsed"]["qualifiers"]], ["N12"])
        self.assertEqual(T.levels(row, V)["family"], "jade-devops")
        self.assertEqual([f["code"] for f in row["_lint"]], [])

    def test_alias_scope_and_range_qualifier(self):
        row = classify(u"feat(mc G3C N16–N18): matched convergence", "pr")
        self.assertEqual(row["_cls"]["scopes"], ["mission-control"])
        self.assertEqual(sorted(q["class"] for q in row["_parsed"]["qualifiers"]), ["gate-phase", "pulse"])
        self.assertIn("T006", [f["code"] for f in row["_lint"]])

    def test_scope_used_as_type(self):
        row = classify("MissionControl: add the burndown chart", "pr")
        self.assertEqual(row["_cls"]["scopes"], ["mission-control"])
        self.assertEqual(row["_cls"]["type"], "feat")
        self.assertIn("T007", [f["code"] for f in row["_lint"]])
        self.assertEqual(T.suggest_title(row, V), "feat(mission-control): add the burndown chart")

    def test_hyphen_prefix_shortening(self):
        row = classify("GM-FLEET-03: ring 2 recon", "pr")
        self.assertEqual(row["_cls"]["scopes"], ["fleet"])

    def test_type_alias(self):
        row = classify("doc(handover): x", "pr")
        self.assertEqual(row["_cls"]["type"], "docs")
        self.assertIn("T003", [f["code"] for f in row["_lint"]])

    def test_unknown_scope_is_kept(self):
        row = classify("fix(zorblax): x", "pr")
        self.assertEqual(T.levels(row, V)["family"], "unmapped")
        self.assertEqual(T.suggest_title(row, V), "fix(zorblax): x")


class InferenceTests(unittest.TestCase):
    def test_ci_failure_issue(self):
        row = classify(u"\U0001F534 CI Failure: tests on master")
        self.assertEqual((row["_cls"]["type"], row["_cls"]["scopes"][0]), ("fix", "ci"))
        self.assertEqual(row["_cls"]["type_source"], "keyword")

    def test_bracket_tag_becomes_qualifier(self):
        row = classify("[U5] DevOps census N12")
        self.assertEqual(row["_cls"]["scopes"], ["census"])
        self.assertEqual([q["token"] for q in row["_parsed"]["qualifiers"]], ["U5"])
        self.assertIn("T008", [f["code"] for f in row["_lint"]])

    def test_generic_alias_not_inferred_from_free_text(self):
        row = classify("Do not merge unless green")
        self.assertEqual(row["_cls"]["scopes"], [])

    def test_issue_inherits_from_closing_pr_then_parent(self):
        rows = [
            {"repo": "r", "kind": "pr", "number": 10, "title": "fix(watch): signed payload", "labels": []},
            {"repo": "r", "kind": "issue", "number": 1, "title": "Owner edge", "labels": [], "closed_by_prs": [10]},
            {"repo": "r", "kind": "issue", "number": 2, "title": "Child item", "labels": [], "parent": 1},
        ]
        T.classify_all(rows, V)
        self.assertEqual(rows[1]["_cls"]["scopes"], ["watch"])
        self.assertEqual(rows[1]["_cls"]["scope_source"], "pr#10")
        self.assertEqual(rows[2]["_cls"]["scopes"], ["watch"])
        self.assertEqual(rows[2]["_cls"]["scope_source"], "parent#1")

    def test_parent_cycle_terminates(self):
        rows = [
            {"repo": "r", "kind": "issue", "number": 1, "title": "a", "labels": [], "parent": 2},
            {"repo": "r", "kind": "issue", "number": 2, "title": "b", "labels": [], "parent": 1},
        ]
        T.classify_all(rows, V)
        self.assertEqual(rows[0]["_cls"]["scopes"], [])

    def test_label_type(self):
        row = classify("Something odd", labels=["bug", "gogreen"])
        self.assertEqual((row["_cls"]["type"], row["_cls"]["scopes"]), ("fix", ["gogreen"]))


class LeadLabelTests(unittest.TestCase):
    def test_wave_lead_label(self):
        row = classify("W327: require owner-controlled attestation for BT0 HEPAK source trust", "pr")
        self.assertEqual(row["_cls"]["scopes"][0], "hepak")
        self.assertEqual([q["token"] for q in row["_parsed"]["qualifiers"]], ["W327"])
        self.assertIn("T011", [f["code"] for f in row["_lint"]])

    def test_scope_and_wave_label(self):
        row = classify("CBD W4: combine native-tested governance inventory", "pr")
        self.assertEqual((row["_cls"]["scopes"], row["_cls"]["scope_source"]), (["cbd"], "lead"))

    def test_wave_in_type_slot(self):
        row = classify("w64(3pr-b): index tracked files with size", "pr")
        self.assertEqual(row["_cls"]["scopes"], ["mip"])
        self.assertIn("W64", [q["token"].upper() for q in row["_parsed"]["qualifiers"]])

    def test_retitle_never_drops_label_tokens(self):
        for title in ["RFI-QPS-CC-01: Close missing cold-compressor evidence", "DMAIC wave control: PR-to-PR progress",
                      "QPS TRIAGE N2: complete native census"]:
            row = classify(title)
            new = T.suggest_title(row, V)
            for word in title.split(":")[0].split():
                self.assertTrue(new is None or word in new, (title, new))

    def test_multiword_scope_label(self):
        row = classify("Mission Control: scale uptake with routing")
        self.assertEqual(row["_cls"]["scopes"][0], "mission-control")

    def test_prose_label_is_not_a_prefix(self):
        row = classify("CI Failure: tests on master")
        self.assertEqual((row["_cls"]["type"], row["_cls"]["scopes"][0]), ("fix", "ci"))


if __name__ == "__main__":
    unittest.main()
