"""Shape out/ census files into the dashboard's attached datasets (out/dash/*.json, row arrays).

    python dash_export.py --raw data/raw.json --out out
"""
import argparse
import csv
import json
import os

STATS_LEVELS = {"type_family", "type", "family", "scope", "prefix", "family_prefix", "qualifier_class"}


def read_csv(path):
    with open(path, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def dump(path, rows):
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(rows, fh, ensure_ascii=False, separators=(",", ":"))
    return os.path.getsize(path)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/raw.json")
    ap.add_argument("--out", default="out")
    args = ap.parse_args(argv)
    d = os.path.join(args.out, "dash")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(args.out, "census.json"), encoding="utf-8") as fh:
        census = json.load(fh)
    with open(args.raw, encoding="utf-8") as fh:
        raw = json.load(fh)
    inv = census["inventory"]

    def num(v):
        return None if v in ("", None) else (float(v) if "." in v else int(v))

    stats = [dict(s, **{k: num(s[k]) for k in ("n", "share", "open", "closed", "merged", "n_30d", "n_prev_30d",
                                               "trend_30d", "median_days_to_close", "rank")})
             for s in read_csv(os.path.join(args.out, "stats.csv")) if s["level"] in STATS_LEVELS]
    series = [dict(s, n=int(s["n"]), cum_n=int(s["cum_n"])) for s in read_csv(os.path.join(args.out, "timeseries.csv"))
              if s["level"] in ("family", "type_family")]
    conformance = [dict(c, **{k: num(c[k]) for k in ("n", "explicit", "clean", "resolved", "explicit_rate", "clean_rate", "resolved_rate")})
                   for c in read_csv(os.path.join(args.out, "conformance.csv"))]
    pulse = [{"repo": r["repo"], "head_sha": r["head_sha"], "default_branch": r["default_branch"],
              "fetched_at": r.get("fetched_at", raw["fetched_at"]),
              "prs": sum(1 for x in r["rows"] if x["kind"] == "pr"),
              "issues": sum(1 for x in r["rows"] if x["kind"] == "issue")} for r in raw["repos"]]
    keywords = []
    for fam in inv["families"]:
        for s in fam["scopes"]:
            keywords.append({"family": fam["family"], "scope": s["scope"],
                             "aliases": ", ".join(s["aliases"]),
                             "explicit_only": ", ".join(s["explicit_only"]),
                             "seen": ", ".join("%s %d" % kv for kv in s["seen"].items()),
                             "n_explicit": s["n_explicit"],
                             "repos": ", ".join("%s %d" % kv for kv in s["by_repo"].items())})
    unmapped = [{"id": "scope:" + u["scope"], "what": "scope", "token": u["scope"], "n": u["n"],
                 "repos": ", ".join("%s %d" % kv for kv in u["by_repo"].items())} for u in inv["unmapped_scopes"]]
    unmapped += [{"id": "type:" + u["type"], "what": "type", "token": u["type"], "n": u["n"],
                  "repos": ", ".join("%s %d" % kv for kv in u["by_repo"].items())} for u in inv["unknown_types"]]
    lint = [{"code": k, "severity": v["severity"], "message": v["message"], "n": v["n"]} for k, v in inv["lint_codes"].items()]
    typemap = [{"type": t["type"], "family": t["family"], "aliases": ", ".join(t["aliases"])} for t in inv["types"]]
    with open(os.path.join(args.out, "issue_plan.json"), encoding="utf-8") as fh:
        plan_items = json.load(fh)["items"]
    plan = [{"id": "%s#%d" % (p["repo"], p["number"]), "repo": p["repo"], "number": p["number"],
             "confidence": p["confidence"], "title": p["title"], "new_title": p["new_title"] or "",
             "add_labels": ", ".join(p["add_labels"]), "bot": p["bot"],
             "evidence": "type from %s, scope from %s" % (p["type_source"] or "-", p["scope_source"] or "-")}
            for p in plan_items]

    titles = [{"id": "%s/%s/%s" % (r["repo"], r["kind"], r["number"]), "repo": r["repo"], "kind": r["kind"],
               "number": int(r["number"]), "title": r["title"], "state": r["state"], "created": r["created"],
               "closed": r["closed"], "type": r["type"], "family": r["family"], "scope": r["scope"],
               "prefix": r["prefix"], "qualifiers": r["qualifiers"], "confidence": r["confidence"], "lint": r["lint"]}
              for r in read_csv(os.path.join(args.out, "rows.csv"))]

    for name, rows in [("titles", titles), ("stats", stats), ("series", series), ("conformance", conformance), ("pulse", pulse),
                       ("keywords", keywords), ("unmapped", unmapped), ("lint", lint), ("typemap", typemap),
                       ("plan", plan)]:
        size = dump(os.path.join(d, name + ".json"), rows)
        print("%-12s %6d rows %9d bytes" % (name, len(rows), size))


if __name__ == "__main__":
    main()
