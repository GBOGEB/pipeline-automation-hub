"""Fetch PR and issue titles for the title-taxonomy census (read-only GitHub GraphQL via `gh`).

One pulse: each repo's default-branch head SHA is read once and stored with its rows (AGENTS.md L6).

    python fetch.py --owner GBOGEB --out data/raw.json [--repos A B ...] [--since 2026-08-01]
"""
import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone

PR_QUERY = """
query($owner:String!, $name:String!, $cursor:String) {
  repository(owner:$owner, name:$name) {
    pullRequests(first:100, after:$cursor, orderBy:{field:CREATED_AT, direction:ASC}) {
      pageInfo { hasNextPage endCursor }
      nodes {
        number title state isDraft createdAt mergedAt closedAt headRefName
        author { login }
        labels(first:20) { nodes { name } }
        closingIssuesReferences(first:10) { nodes { number repository { name } } }
      }
    }
  }
}"""

ISSUE_QUERY = """
query($owner:String!, $name:String!, $cursor:String) {
  repository(owner:$owner, name:$name) {
    issues(first:100, after:$cursor, orderBy:{field:CREATED_AT, direction:ASC}) {
      pageInfo { hasNextPage endCursor }
      nodes {
        number title state stateReason createdAt closedAt
        author { login }
        labels(first:20) { nodes { name } }
        parent { number repository { name } }
        subIssuesSummary { total }
        closedByPullRequestsReferences(first:10, includeClosedPrs:true) { nodes { number repository { name } } }
      }
    }
  }
}"""

HEAD_QUERY = """
query($owner:String!, $name:String!) {
  repository(owner:$owner, name:$name) {
    isFork isArchived
    defaultBranchRef { name target { oid } }
  }
}"""


def gh_graphql(query, **variables):
    env = dict(os.environ)
    env.pop("GITHUB_TOKEN", None)
    env.pop("GH_TOKEN", None)
    cmd = ["gh", "api", "graphql", "-f", "query=" + query]
    for key, value in variables.items():
        if value is not None:
            cmd += ["-F", "%s=%s" % (key, value)]
    for attempt in range(6):
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", env=env)
        if proc.returncode == 0:
            return json.loads(proc.stdout)["data"]
        sys.stderr.write("gh graphql failed (attempt %d): %s\n" % (attempt + 1, proc.stderr.strip()[:300]))
        time.sleep(5 * (attempt + 1))
    raise RuntimeError("gh graphql failed: " + proc.stderr)


def paged(query, owner, name, conn):
    cursor = None
    while True:
        data = gh_graphql(query, owner=owner, name=name, cursor=cursor)
        block = data["repository"][conn]
        for node in block["nodes"]:
            yield node
        if not block["pageInfo"]["hasNextPage"]:
            return
        cursor = block["pageInfo"]["endCursor"]


def flat_labels(node):
    return [l["name"] for l in (node.get("labels") or {}).get("nodes", [])]


def fetch_repo(owner, name):
    head = gh_graphql(HEAD_QUERY, owner=owner, name=name)["repository"]
    ref = head.get("defaultBranchRef") or {}
    rows = []
    for n in paged(PR_QUERY, owner, name, "pullRequests"):
        rows.append({
            "repo": name, "kind": "pr", "number": n["number"], "title": n["title"],
            "state": "merged" if n["mergedAt"] else n["state"].lower(), "draft": n["isDraft"],
            "created": n["createdAt"], "closed": n["mergedAt"] or n["closedAt"],
            "author": (n.get("author") or {}).get("login"), "labels": flat_labels(n),
            "branch": n["headRefName"],
            "closes": [{"repo": i["repository"]["name"], "number": i["number"]}
                       for i in (n.get("closingIssuesReferences") or {}).get("nodes", [])],
        })
    for n in paged(ISSUE_QUERY, owner, name, "issues"):
        rows.append({
            "repo": name, "kind": "issue", "number": n["number"], "title": n["title"],
            "state": n["state"].lower(), "state_reason": n.get("stateReason"),
            "created": n["createdAt"], "closed": n["closedAt"],
            "author": (n.get("author") or {}).get("login"), "labels": flat_labels(n),
            # same-repo numbers drive recursive inheritance; *_ref(s) keep cross-repo edges for the graph
            "parent": (n["parent"]["number"] if n.get("parent") and n["parent"]["repository"]["name"] == name else None),
            "parent_ref": ({"repo": n["parent"]["repository"]["name"], "number": n["parent"]["number"]}
                           if n.get("parent") else None),
            "sub_issues": (n.get("subIssuesSummary") or {}).get("total", 0),
            "closed_by_prs": [p["number"] for p in (n.get("closedByPullRequestsReferences") or {}).get("nodes", [])
                              if p["repository"]["name"] == name],
            "closed_by_refs": [{"repo": p["repository"]["name"], "number": p["number"]}
                               for p in (n.get("closedByPullRequestsReferences") or {}).get("nodes", [])],
        })
    return {
        "repo": name, "default_branch": ref.get("name"),
        "head_sha": (ref.get("target") or {}).get("oid"),
        "is_fork": head["isFork"], "rows": rows,
    }


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--owner", default="GBOGEB")
    ap.add_argument("--repos", nargs="*")
    ap.add_argument("--since", default="2026-08-01", help="when --repos is omitted: source repos pushed since this date")
    ap.add_argument("--out", default="data/raw.json")
    ap.add_argument("--resume", action="store_true", help="reuse per-repo files already fetched in data/repos/")
    args = ap.parse_args(argv)

    repos = args.repos
    if not repos:
        env = dict(os.environ)
        env.pop("GITHUB_TOKEN", None)
        env.pop("GH_TOKEN", None)
        out = subprocess.run(
            ["gh", "repo", "list", args.owner, "--source", "--limit", "300", "--json", "name,pushedAt,isArchived"],
            capture_output=True, text=True, encoding="utf-8", env=env, check=True).stdout
        repos = sorted(r["name"] for r in json.loads(out) if r["pushedAt"] >= args.since and not r["isArchived"])

    pulse = {"schema": "gbogeb.title-taxonomy.raw/1.0", "owner": args.owner,
             "fetched_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "repos": []}
    cache = os.path.join(os.path.dirname(args.out) or ".", "repos")
    os.makedirs(cache, exist_ok=True)
    for name in repos:
        path = os.path.join(cache, name + ".json")
        if args.resume and os.path.exists(path):
            sys.stderr.write("cached %s/%s\n" % (args.owner, name))
            with open(path, encoding="utf-8") as fh:
                pulse["repos"].append(json.load(fh))
            continue
        sys.stderr.write("fetch %s/%s\n" % (args.owner, name))
        repo = fetch_repo(args.owner, name)
        repo["fetched_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(repo, fh, ensure_ascii=False)
        pulse["repos"].append(repo)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(pulse, fh, ensure_ascii=False, indent=1)
    total = sum(len(r["rows"]) for r in pulse["repos"])
    sys.stderr.write("wrote %s: %d repos, %d rows\n" % (args.out, len(pulse["repos"]), total))


if __name__ == "__main__":
    main()
