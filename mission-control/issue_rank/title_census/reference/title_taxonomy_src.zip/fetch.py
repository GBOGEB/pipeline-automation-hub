"""Fetch PR and issue titles for the title-taxonomy census (read-only GitHub GraphQL via `gh`).

One pulse: each repo's default-branch head SHA is read once and stored with its rows (AGENTS.md L6).

    python fetch.py --owner GBOGEB --out data/raw.json [--repos A B ...] [--since 2026-08-01] [--resume]

A fresh run writes data/repos/_run.json (run id and start time). --resume continues that run only: it reuses
per-repo files carrying the same run id and never mixes in files from an earlier run, and the pulse keeps the
run's start time as fetched_at.
"""
import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone

import graph

# Bodies are read only to extract references (graph.body_refs) and are never stored.
XREF_NODES = """
          pageInfo { hasNextPage endCursor }
          nodes { ... on CrossReferencedEvent { willCloseTarget source {
            ... on Issue { number repository { name owner { login } } }
            ... on PullRequest { number repository { name owner { login } } } } } }"""
LINKS = """
        id body
        timelineItems(first:30, itemTypes:[CROSS_REFERENCED_EVENT]) {%s
        }""" % XREF_NODES

# Further pages of cross-reference events for one PR / issue (the first page rides on the list query).
MORE_XREFS = """
query($id:ID!, $cursor:String) {
  node(id:$id) {
    ... on Issue { timelineItems(first:100, after:$cursor, itemTypes:[CROSS_REFERENCED_EVENT]) {%s } }
    ... on PullRequest { timelineItems(first:100, after:$cursor, itemTypes:[CROSS_REFERENCED_EVENT]) {%s } }
  }
}""" % (XREF_NODES, XREF_NODES)

PR_QUERY = """
query($owner:String!, $name:String!, $cursor:String) {
  repository(owner:$owner, name:$name) {
    pullRequests(first:50, after:$cursor, orderBy:{field:CREATED_AT, direction:ASC}) {
      pageInfo { hasNextPage endCursor }
      nodes {
        number title state isDraft createdAt mergedAt closedAt headRefName
        author { login }
        labels(first:20) { nodes { name } }
        closingIssuesReferences(first:10) { nodes { number repository { name } } }%s
      }
    }
  }
}""" % LINKS

ISSUE_QUERY = """
query($owner:String!, $name:String!, $cursor:String) {
  repository(owner:$owner, name:$name) {
    issues(first:50, after:$cursor, orderBy:{field:CREATED_AT, direction:ASC}) {
      pageInfo { hasNextPage endCursor }
      nodes {
        number title state stateReason createdAt closedAt
        author { login }
        labels(first:20) { nodes { name } }
        parent { number repository { name } }
        subIssuesSummary { total }
        closedByPullRequestsReferences(first:10, includeClosedPrs:true) { nodes { number repository { name } } }%s
      }
    }
  }
}""" % LINKS

HEAD_QUERY = """
query($owner:String!, $name:String!) {
  repository(owner:$owner, name:$name) {
    isFork isArchived
    defaultBranchRef { name target { oid } }
  }
}"""


def gh_graphql(query, **variables):
    env = dict(os.environ)
    env.pop("GITHUB_TOKEN", None)
    env.pop("GH_TOKEN", None)
    cmd = ["gh", "api", "graphql", "-f", "query=" + query]
    for key, value in variables.items():
        if value is not None:
            cmd += ["-F", "%s=%s" % (key, value)]
    for attempt in range(6):
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", env=env)
        if proc.returncode == 0:
            return json.loads(proc.stdout)["data"]
        sys.stderr.write("gh graphql failed (attempt %d): %s\n" % (attempt + 1, proc.stderr.strip()[:300]))
        time.sleep(5 * (attempt + 1))
    raise RuntimeError("gh graphql failed: " + proc.stderr)


def paged(query, owner, name, conn):
    cursor = None
    while True:
        data = gh_graphql(query, owner=owner, name=name, cursor=cursor)
        block = data["repository"][conn]
        for node in block["nodes"]:
            yield node
        if not block["pageInfo"]["hasNextPage"]:
            return
        cursor = block["pageInfo"]["endCursor"]


def flat_labels(node):
    return [l["name"] for l in (node.get("labels") or {}).get("nodes", [])]


def links(n, owner, name):
    """Body references and timeline cross-references of one PR / issue node, owner-local only."""
    xrefs = []
    block = n.get("timelineItems") or {}
    while True:
        for ev in block.get("nodes", []):
            src = (ev or {}).get("source") or {}
            repo = src.get("repository") or {}
            if src.get("number") and (repo.get("owner") or {}).get("login") == owner:
                xrefs.append({"repo": repo["name"], "number": src["number"], "will_close": bool(ev.get("willCloseTarget"))})
        page = block.get("pageInfo") or {}
        if not page.get("hasNextPage"):
            break
        block = gh_graphql(MORE_XREFS, id=n["id"], cursor=page["endCursor"])["node"]["timelineItems"]
    return {"body_refs": graph.body_refs(n.get("body") or "", owner, name), "xrefs": xrefs}


def fetch_repo(owner, name):
    head = gh_graphql(HEAD_QUERY, owner=owner, name=name)["repository"]
    ref = head.get("defaultBranchRef") or {}
    rows = []
    for n in paged(PR_QUERY, owner, name, "pullRequests"):
        rows.append({
            "repo": name, "kind": "pr", "number": n["number"], "title": n["title"],
            "state": "merged" if n["mergedAt"] else n["state"].lower(), "draft": n["isDraft"],
            "created": n["createdAt"], "closed": n["mergedAt"] or n["closedAt"],
            "author": (n.get("author") or {}).get("login"), "labels": flat_labels(n),
            "branch": n["headRefName"],
            "closes": [{"repo": i["repository"]["name"], "number": i["number"]}
                       for i in (n.get("closingIssuesReferences") or {}).get("nodes", [])],
            **links(n, owner, name)
        })
    for n in paged(ISSUE_QUERY, owner, name, "issues"):
        rows.append({
            "repo": name, "kind": "issue", "number": n["number"], "title": n["title"],
            "state": n["state"].lower(), "state_reason": n.get("stateReason"),
            "created": n["createdAt"], "closed": n["closedAt"],
            "author": (n.get("author") or {}).get("login"), "labels": flat_labels(n),
            # same-repo numbers drive recursive inheritance; *_ref(s) keep cross-repo edges for the graph
            "parent": (n["parent"]["number"] if n.get("parent") and n["parent"]["repository"]["name"] == name else None),
            "parent_ref": ({"repo": n["parent"]["repository"]["name"], "number": n["parent"]["number"]}
                           if n.get("parent") else None),
            "sub_issues": (n.get("subIssuesSummary") or {}).get("total", 0),
            "closed_by_prs": [p["number"] for p in (n.get("closedByPullRequestsReferences") or {}).get("nodes", [])
                              if p["repository"]["name"] == name],
            "closed_by_refs": [{"repo": p["repository"]["name"], "number": p["number"]}
                               for p in (n.get("closedByPullRequestsReferences") or {}).get("nodes", [])],
            **links(n, owner, name)
        })
    return {
        "repo": name, "default_branch": ref.get("name"),
        "head_sha": (ref.get("target") or {}).get("oid"),
        "is_fork": head["isFork"], "rows": rows,
    }


def start_run(cache, owner, resume):
    """Open the run that every per-repo cache file must belong to (AGENTS.md L6: one pulse, one run)."""
    os.makedirs(cache, exist_ok=True)
    marker = os.path.join(cache, "_run.json")
    if resume:
        if not os.path.exists(marker):
            raise SystemExit("--resume: no run to resume in %s; start a fresh run without --resume" % cache)
        with open(marker, encoding="utf-8") as fh:
            run = json.load(fh)
        if run.get("owner") != owner:
            raise SystemExit("--resume: the cached run is for owner %s, not %s" % (run.get("owner"), owner))
        return run
    now = datetime.now(timezone.utc)
    run = {"run_id": now.strftime("%Y%m%dT%H%M%S%fZ"), "started_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "owner": owner}
    with open(marker, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(run, fh)
    return run


def load_cached(path, run_id):
    """A per-repo file from this run, or None (missing, or written by another run: refetch, never mix)."""
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as fh:
        repo = json.load(fh)
    if repo.get("run_id") != run_id:
        sys.stderr.write("ignore %s: written by run %s, not %s\n" % (path, repo.get("run_id"), run_id))
        return None
    return repo


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--owner", default="GBOGEB")
    ap.add_argument("--repos", nargs="*")
    ap.add_argument("--since", default="2026-08-01", help="when --repos is omitted: source repos pushed since this date")
    ap.add_argument("--out", default="data/raw.json")
    ap.add_argument("--resume", action="store_true", help="reuse per-repo files already fetched in data/repos/")
    args = ap.parse_args(argv)

    repos = args.repos
    if not repos:
        env = dict(os.environ)
        env.pop("GITHUB_TOKEN", None)
        env.pop("GH_TOKEN", None)
        out = subprocess.run(
            ["gh", "repo", "list", args.owner, "--source", "--limit", "300", "--json", "name,pushedAt,isArchived"],
            capture_output=True, text=True, encoding="utf-8", env=env, check=True).stdout
        repos = sorted(r["name"] for r in json.loads(out) if r["pushedAt"] >= args.since and not r["isArchived"])

    cache = os.path.join(os.path.dirname(args.out) or ".", "repos")
    run = start_run(cache, args.owner, args.resume)
    pulse = {"schema": "gbogeb.title-taxonomy.raw/1.0", "owner": args.owner, "run_id": run["run_id"],
             "fetched_at": run["started_at"], "repos": []}
    for name in repos:
        path = os.path.join(cache, name + ".json")
        cached = load_cached(path, run["run_id"]) if args.resume else None
        if cached is not None:
            sys.stderr.write("cached %s/%s (run %s)\n" % (args.owner, name, run["run_id"]))
            pulse["repos"].append(cached)
            continue
        sys.stderr.write("fetch %s/%s\n" % (args.owner, name))
        repo = fetch_repo(args.owner, name)
        repo["run_id"] = run["run_id"]
        repo["fetched_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(repo, fh, ensure_ascii=False)
        pulse["repos"].append(repo)

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(pulse, fh, ensure_ascii=False, indent=1)
    total = sum(len(r["rows"]) for r in pulse["repos"])
    sys.stderr.write("wrote %s: %d repos, %d rows\n" % (args.out, len(pulse["repos"]), total))


if __name__ == "__main__":
    main()
