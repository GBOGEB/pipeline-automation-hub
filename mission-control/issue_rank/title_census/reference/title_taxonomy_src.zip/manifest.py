"""Write MANIFEST.json: sha256 and size of every artefact, the pulse SHAs, and the dashboard blob ids.

    python manifest.py [--check]

--check regenerates out/ from data/raw.json.gz into a temp dir and fails if any output hash differs,
which proves the committed outputs are reproducible from the committed pulse (lossless handover).
"""
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUTS = ["out/census.json", "out/rows.csv", "out/stats.csv", "out/timeseries.csv", "out/conformance.csv",
           "out/keywords.md", "out/issue_plan.json", "out/issue_plan.md", "out/edges.csv"]
DASH = ["titles", "edges", "stats", "series", "conformance", "pulse", "keywords", "unmapped", "lint", "typemap", "plan"]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def regenerate(raw_gz, workdir):
    raw = os.path.join(workdir, "raw.json")
    with gzip.open(raw_gz, "rb") as src, open(raw, "wb") as dst:
        shutil.copyfileobj(src, dst)
    out = os.path.join(workdir, "out")
    subprocess.check_call([sys.executable, os.path.join(HERE, "report.py"), "--raw", raw, "--out", out], cwd=HERE,
                          stdout=subprocess.DEVNULL)
    subprocess.check_call([sys.executable, os.path.join(HERE, "dash_export.py"), "--raw", raw, "--out", out], cwd=HERE,
                          stdout=subprocess.DEVNULL)
    return out


def main():
    os.chdir(HERE)
    if "--check" in sys.argv:
        with open("MANIFEST.json", encoding="utf-8") as fh:
            man = json.load(fh)
        tmp = tempfile.mkdtemp()
        try:
            out = regenerate("data/raw.json.gz", tmp)
            bad = []
            for rel, meta in man["outputs"].items():
                got = sha(os.path.join(out, os.path.relpath(rel, "out")))
                if got != meta["sha256"]:
                    bad.append(rel)
            print("reproducible" if not bad else "DIFFERS: " + ", ".join(bad))
            sys.exit(1 if bad else 0)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    with gzip.open("data/raw.json.gz", "rt", encoding="utf-8") as fh:
        raw = json.load(fh)
    blobs = {}
    if os.path.exists("out/dash/blobs.json"):
        with open("out/dash/blobs.json", encoding="utf-8") as fh:
            blobs = json.load(fh)
    man = {
        "schema": "gbogeb.title-taxonomy.manifest/1.0",
        "pulse": {"fetched_at": raw["fetched_at"], "owner": raw["owner"],
                  "repos": {r["repo"]: r["head_sha"] for r in raw["repos"]}},
        "source": {"data/raw.json.gz": {"sha256": sha("data/raw.json.gz"), "bytes": os.path.getsize("data/raw.json.gz"),
                                        "rows": sum(len(r["rows"]) for r in raw["repos"])},
                   "vocabulary.json": {"sha256": sha("vocabulary.json")}},
        "outputs": {p: {"sha256": sha(p), "bytes": os.path.getsize(p)} for p in OUTPUTS},
        "dashboard": {"url": "https://claude.ai/artifact/RARdwhuvVk2emp2iCRRhDw",
                      "page": {"dash/index.html": sha("dash/index.html")},
                      "datasets": {d: {"file": "out/dash/%s.json" % d, "sha256": sha("out/dash/%s.json" % d),
                                       "blob": blobs.get(d)} for d in DASH}},
    }
    with open("MANIFEST.json", "w", encoding="utf-8", newline="\n") as fh:
        json.dump(man, fh, indent=1)
    print("MANIFEST.json: %d outputs, %d datasets" % (len(man["outputs"]), len(DASH)))


if __name__ == "__main__":
    main()
