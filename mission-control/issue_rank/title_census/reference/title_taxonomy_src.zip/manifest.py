"""Write MANIFEST.json: sha256 and size of every artefact, the pulse SHAs, and the dashboard blob ids.

    python manifest.py [--check] [--pah <pipeline-automation-hub checkout>]

--check regenerates out/ from data/raw.json.gz into a temp dir and fails if any output hash differs,
which proves the committed outputs are reproducible from the committed pulse (lossless handover).
With --pah (a checkout holding the owner modules red_trace.py, cicd_dag.py and their data) the CI outputs
are regenerated from data/checks.json.gz and checked as well.
"""
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
OUTPUTS = ["out/census.json", "out/rows.csv", "out/stats.csv", "out/timeseries.csv", "out/conformance.csv",
           "out/keywords.md", "out/issue_plan.json", "out/issue_plan.md", "out/edges.csv"]
CI_OUTPUTS = ["out/ci_family.csv", "out/ci_checks.csv", "out/ci_signatures.csv", "out/ci_prs.csv"]
DASH = ["titles", "edges", "ci_family", "ci_checks", "ci_signatures", "stats", "series", "conformance", "pulse", "keywords", "unmapped", "lint", "typemap", "plan"]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def pah_arg():
    return sys.argv[sys.argv.index("--pah") + 1] if "--pah" in sys.argv else None


def regenerate(raw_gz, workdir, pah=None):
    raw = os.path.join(workdir, "raw.json")
    with gzip.open(raw_gz, "rb") as src, open(raw, "wb") as dst:
        shutil.copyfileobj(src, dst)
    out = os.path.join(workdir, "out")
    subprocess.check_call([sys.executable, os.path.join(HERE, "report.py"), "--raw", raw, "--out", out], cwd=HERE,
                          stdout=subprocess.DEVNULL)
    subprocess.check_call([sys.executable, os.path.join(HERE, "dash_export.py"), "--raw", raw, "--out", out], cwd=HERE,
                          stdout=subprocess.DEVNULL)
    if pah:
        checks = os.path.join(workdir, "checks.json")
        with gzip.open(os.path.join(HERE, "data", "checks.json.gz"), "rb") as src, open(checks, "wb") as dst:
            shutil.copyfileobj(src, dst)
        subprocess.check_call([sys.executable, os.path.join(HERE, "ci_census.py"), "--pah", pah, "--checks", checks,
                               "--out", out], cwd=HERE, stdout=subprocess.DEVNULL)
    return out


def main():
    os.chdir(HERE)
    if "--check" in sys.argv:
        with open("MANIFEST.json", encoding="utf-8") as fh:
            man = json.load(fh)
        tmp = tempfile.mkdtemp()
        try:
            out = regenerate("data/raw.json.gz", tmp, pah_arg())
            bad = []
            for rel, meta in man["outputs"].items():
                if rel in CI_OUTPUTS and not pah_arg():
                    continue
                got = sha(os.path.join(out, os.path.relpath(rel, "out")))
                if got != meta["sha256"]:
                    bad.append(rel)
            print(("reproducible" if not bad else "DIFFERS: " + ", ".join(bad))
                  + ("" if pah_arg() else " (CI outputs not checked: pass --pah)"))
            sys.exit(1 if bad else 0)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    with gzip.open("data/raw.json.gz", "rt", encoding="utf-8") as fh:
        raw = json.load(fh)
    blobs = {}
    if os.path.exists("out/dash/blobs.json"):
        with open("out/dash/blobs.json", encoding="utf-8") as fh:
            blobs = json.load(fh)
    man = {
        "schema": "gbogeb.title-taxonomy.manifest/1.0",
        "pulse": {"fetched_at": raw["fetched_at"], "owner": raw["owner"],
                  "repos": {r["repo"]: r["head_sha"] for r in raw["repos"]}},
        "source": {"data/raw.json.gz": {"sha256": sha("data/raw.json.gz"), "bytes": os.path.getsize("data/raw.json.gz"),
                                        "rows": sum(len(r["rows"]) for r in raw["repos"])},
                   "data/checks.json.gz": {"sha256": sha("data/checks.json.gz")},
                   "vocabulary.json": {"sha256": sha("vocabulary.json")}},
        "outputs": {p: {"sha256": sha(p), "bytes": os.path.getsize(p)} for p in OUTPUTS + CI_OUTPUTS},
        "dashboard": {"url": "https://claude.ai/artifact/RARdwhuvVk2emp2iCRRhDw",
                      "page": {"dash/index.html": sha("dash/index.html")},
                      "datasets": {d: {"file": "out/dash/%s.json" % d, "sha256": sha("out/dash/%s.json" % d),
                                       "blob": blobs.get(d)} for d in DASH}},
    }
    with open("MANIFEST.json", "w", encoding="utf-8", newline="\n") as fh:
        json.dump(man, fh, indent=1)
    print("MANIFEST.json: %d outputs, %d datasets" % (len(man["outputs"]), len(DASH)))


if __name__ == "__main__":
    main()
