"""python -m unittest test_fetch  (no network: gh_graphql is replaced by a fake)"""
import json
import os
import shutil
import tempfile
import unittest

import fetch
import fetch_checks


def xref(n):
    return {"willCloseTarget": False, "source": {"number": n, "repository": {"name": "A", "owner": {"login": "O"}}}}


class PaginationTests(unittest.TestCase):
    def setUp(self):
        self.calls = []
        self._f, self._c = fetch.gh_graphql, fetch_checks.gh_graphql

    def tearDown(self):
        fetch.gh_graphql, fetch_checks.gh_graphql = self._f, self._c

    def test_timeline_follows_cursor_past_first_page(self):
        def fake(query, **v):
            self.calls.append(v)
            return {"node": {"timelineItems": {"pageInfo": {"hasNextPage": False, "endCursor": None},
                                               "nodes": [xref(i) for i in range(31, 46)]}}}
        fetch.gh_graphql = fake
        node = {"id": "I_1", "body": "", "timelineItems": {"pageInfo": {"hasNextPage": True, "endCursor": "c30"},
                                                           "nodes": [xref(i) for i in range(1, 31)]}}
        got = fetch.links(node, "O", "A")["xrefs"]
        self.assertEqual(len(got), 45)
        self.assertEqual(self.calls, [{"id": "I_1", "cursor": "c30"}])

    def test_check_suites_follow_cursor_past_first_page(self):
        suite = lambda i: {"conclusion": "SUCCESS", "status": "COMPLETED",
                           "workflowRun": {"databaseId": i, "file": {"path": "w%d.yml" % i}, "workflow": {"name": "w%d" % i}}}
        fetch_checks.gh_graphql = lambda q, **v: {"node": {"checkSuites": {"pageInfo": {"hasNextPage": False},
                                                                           "nodes": [suite(i) for i in range(30, 33)]}}}
        commit = {"id": "C_1", "checkSuites": {"pageInfo": {"hasNextPage": True, "endCursor": "s30"},
                                               "nodes": [suite(i) for i in range(30)]}}
        self.assertEqual(len(fetch_checks.all_suites(commit)), 33)


class RunBindingTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.dir, ignore_errors=True)

    def test_resume_rejects_files_from_another_run(self):
        run = fetch.start_run(self.dir, "O", resume=False)
        with open(os.path.join(self.dir, "A.json"), "w") as fh:
            json.dump({"repo": "A", "run_id": "an-earlier-run"}, fh)
        with open(os.path.join(self.dir, "B.json"), "w") as fh:
            json.dump({"repo": "B", "run_id": run["run_id"]}, fh)
        resumed = fetch.start_run(self.dir, "O", resume=True)
        self.assertEqual(resumed, run)
        self.assertIsNone(fetch.load_cached(os.path.join(self.dir, "A.json"), resumed["run_id"]))
        self.assertEqual(fetch.load_cached(os.path.join(self.dir, "B.json"), resumed["run_id"])["repo"], "B")

    def test_resume_without_a_run_fails(self):
        with self.assertRaises(SystemExit):
            fetch.start_run(self.dir, "O", resume=True)


if __name__ == "__main__":
    unittest.main()
