"""Title taxonomy for PRs and issues: parse, lint, classify and inherit `type(scope qualifiers): subject`.

Grammar (see vocabulary.json):

    <type>(<scope>[,<scope>][ <qualifier>...])[!]: <subject>

    fix(jade devops N12): census fails closed when blobs are missing
    ^^^ ^^^^^^^^^^^ ^^^   ^ subject
    |   |           qualifier (pulse N12)
    |   scope -> family jade-devops
    type -> type family defect

Every row resolves to the levels type_family > type and family > scope (+ qualifiers); the
prefix is the concatenation type(scope). Rows without an explicit prefix are classified from
labels, the branch name, keywords, and for issues recursively from closing PRs, the parent issue
and sub-issues, so issues and PRs share one vocabulary.
"""
import json
import os
import re
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))

PREFIX_RE = re.compile(
    r"^(?P<type>[A-Za-z][A-Za-z0-9_-]*)\s*(?:\((?P<scope>[^()]*)\))?\s*(?P<bang>!)?\s*:\s*(?P<subject>.*)$")
TAG_RE = re.compile(r"^\s*\[(?P<tag>[^\]]{1,40})\]\s*")
LEAD_JUNK_RE = re.compile(r"^[^\w\[(]+", re.UNICODE)
BRANCH_RE = re.compile(r"^(?P<type>[A-Za-z]+)[/_-](?P<rest>.+)$")

SEVERITY = {"error": 3, "warning": 2, "info": 1}
LINT_RULES = {
    "T001": ("error", "no type(scope): prefix"),
    "T002": ("error", "unknown type"),
    "T003": ("info", "type alias, use the canonical type"),
    "T004": ("warning", "missing scope"),
    "T005": ("warning", "scope not in vocabulary"),
    "T006": ("info", "scope alias, use the canonical scope"),
    "T007": ("warning", "scope used as type (e.g. 'MissionControl: ...')"),
    "T008": ("info", "bracket tag outside the prefix, move it into the scope as a qualifier"),
    "T009": ("info", "subject longer than 100 characters"),
    "T010": ("warning", "empty subject"),
    "T011": ("info", "freeform lead label (e.g. 'W327: ...'), rewrite as type(scope qualifier):"),
}


def norm(text):
    """Normalize a scope/type token: case, spaces, underscores and en dashes fold to '-'."""
    return re.sub(r"[\s_–]+", "-", text.strip().lower()).strip("-")


class Vocabulary(object):
    def __init__(self, path=None):
        path = path or os.path.join(HERE, "vocabulary.json")
        with open(path, encoding="utf-8") as fh:
            self.raw = json.load(fh)
        self.types = {}          # alias or canonical -> canonical type
        self.type_family = {}
        for canon, spec in self.raw["types"].items():
            self.types[canon] = canon
            self.type_family[canon] = spec["family"]
            for alias in spec["aliases"]:
                self.types[norm(alias)] = canon
        self.scopes = {}         # normalized alias -> canonical scope
        self.scope_family = {}   # canonical scope -> family
        self.family_label = {}
        self.inferable = []      # (regex, canonical scope, alias length) for free-text inference
        for fam, spec in self.raw["families"].items():
            self.family_label[fam] = spec.get("label", fam)
            for canon, aliases in spec["scopes"].items():
                self.scope_family[canon] = fam
                self.scopes[norm(canon)] = canon
                self._add_inferable(canon, canon)
                for alias in aliases:
                    explicit_only = alias.startswith("=")
                    alias = alias.lstrip("=")
                    self.scopes[norm(alias)] = canon
                    if not explicit_only:
                        self._add_inferable(alias, canon)
        self.inferable.sort(key=lambda item: -item[2])
        self.qualifiers = [(q["class"], re.compile(q["pattern"], re.I)) for q in self.raw["qualifiers"]]
        self.type_keywords = [(t, re.compile(rx, re.I)) for t, rx in self.raw["type_keywords"]]
        self.label_types = {norm(k): v for k, v in self.raw.get("label_types", {}).items()}

    def _add_inferable(self, alias, canon):
        if len(alias) < 2:
            return
        body = r"[\s_-]?".join(re.escape(part) for part in re.split(r"[\s_-]+", alias.lower()))
        self.inferable.append((re.compile(r"(?<![a-z0-9])" + body + r"(?![a-z0-9])"), canon, len(alias)))

    # -- lookups -----------------------------------------------------------------------------
    def type_of(self, token):
        return self.types.get(norm(token))

    def scope_of(self, phrase):
        """Resolve a scope phrase; returns (canonical, leftover tokens) or (None, [])."""
        key = norm(phrase)
        if key in self.scopes:
            return self.scopes[key], []
        parts = key.split("-")
        for cut in range(len(parts) - 1, 0, -1):   # gm-fleet-03 -> gm-fleet + ['03']
            head = "-".join(parts[:cut])
            if head in self.scopes:
                return self.scopes[head], parts[cut:]
        return None, []

    def qualifier_class(self, token):
        for cls, rx in self.qualifiers:
            if rx.match(token):
                return cls
        return None

    def infer_scopes(self, text):
        """Canonical scopes mentioned in free text, ordered by first position (longest alias wins)."""
        text = (text or "").lower()
        taken = []
        hits = []
        for rx, canon, _ in self.inferable:
            for m in rx.finditer(text):
                span = (m.start(), m.end())
                if any(s < span[1] and span[0] < e for s, e in taken):
                    continue
                taken.append(span)
                hits.append((m.start(), canon))
        seen = []
        generic = lambda canon: bool(self.raw["families"][self.scope_family[canon]].get("generic"))
        for _, canon in sorted(hits, key=lambda h: (generic(h[1]), h[0])):
            if canon not in seen:
                seen.append(canon)
        return seen

    def infer_type(self, text):
        for canon, rx in self.type_keywords:
            if rx.search(text or ""):
                return canon
        return None


# -- parsing -----------------------------------------------------------------------------------

def parse_title(title, vocab):
    """Split a title into tags, raw type, scopes, qualifiers and subject. No inference here."""
    out = {"raw_title": title, "tags": [], "raw_type": None, "raw_scope": None, "breaking": False,
           "scopes": [], "unknown_scopes": [], "scope_aliases": [], "qualifiers": [], "subject": title.strip(),
           "has_prefix": False}
    rest = LEAD_JUNK_RE.sub("", title.strip())
    while True:
        m = TAG_RE.match(rest)
        if not m:
            break
        out["tags"].append(m.group("tag").strip())
        rest = rest[m.end():]
    for tag in out["tags"]:
        cls = vocab.qualifier_class(tag)
        if cls:
            out["qualifiers"].append({"token": tag, "class": cls})
    m = PREFIX_RE.match(rest)
    if m and m.group("scope") is None and not vocab.type_of(m.group("type")) and not vocab.scope_of(m.group("type"))[0]:
        m = None
    if m and vocab.qualifier_class(m.group("type")) and not vocab.type_of(m.group("type")):
        # "W64(3pr-b): ..." - a wave/step marker where the type belongs: keep it as a qualifier
        out["qualifiers"].append({"token": m.group("type"), "class": vocab.qualifier_class(m.group("type"))})
        out["lead_label"] = m.group("type")
        out["subject"] = m.group("subject").strip()
        if m.group("scope"):
            _scope_part(out, m.group("scope"), vocab)
        return out
    if not m:
        out["subject"] = rest.strip()
        _lead_label(out, rest, vocab)
        return out
    out["has_prefix"] = True
    out["raw_type"] = m.group("type")
    out["raw_scope"] = m.group("scope")
    out["breaking"] = bool(m.group("bang"))
    out["subject"] = m.group("subject").strip()
    if not vocab.type_of(out["raw_type"]):
        canon, leftover = vocab.scope_of(out["raw_type"])
        if canon and leftover:                       # 'RFI-QPS-CC-01:' keeps its id as a qualifier
            out["qualifiers"].append({"token": out["raw_type"], "class": vocab.qualifier_class(out["raw_type"]) or "ticket"})
    if m.group("scope"):
        _scope_part(out, m.group("scope"), vocab)
    return out


def _scope_part(out, scope_text, vocab):
    """Resolve the text inside the brackets into canonical scopes and qualifiers."""
    for part in re.split(r"[,/;|]", scope_text):
        words, quals = [], []
        for token in part.split():
            if norm(token) not in vocab.scopes and vocab.qualifier_class(token):
                quals.append(token)
            else:
                words.append(token)
        out["qualifiers"] += [{"token": q, "class": vocab.qualifier_class(q)} for q in quals]
        if not words:
            continue
        phrase = " ".join(words)
        canon, leftover = vocab.scope_of(phrase)
        if canon is None and len(words) > 1:          # "mc G3P": head word is the scope
            canon, leftover = vocab.scope_of(words[0])
            leftover = leftover + [norm(w) for w in words[1:]]
        if canon is None:
            out["unknown_scopes"].append(norm(phrase))
            continue
        if norm(phrase) != norm(canon):
            out["scope_aliases"].append((phrase, canon))
        if canon not in out["scopes"]:
            out["scopes"].append(canon)
        out["qualifiers"] += [{"token": t, "class": vocab.qualifier_class(t) or "other"} for t in leftover]


LEAD_RE = re.compile(r"^(?P<head>[^:()]{1,48}?)\s*:\s+(?P<subject>\S.*)$")
BRANCHY_RE = re.compile(r"^(?P<type>[A-Za-z]+)/(?P<subject>\S.*)$")


def _lead_label(out, rest, vocab):
    """Freeform lead labels such as 'W327: ...', 'CBD W4: ...', 'GM14 DAB-HARD: ...', 'Feature/dow x'.

    Tokens of the label that are qualifiers, types or scopes are extracted; the title still lacks a
    conventional prefix (T001) but its markers count as evidence from the title itself."""
    m = LEAD_RE.match(rest)
    if m:
        tokens = re.split(r"[\s/]+", m.group("head").strip())
        if len(tokens) > 6:
            return
    else:
        m = BRANCHY_RE.match(rest)
        if not m or not TYPES_FROM_BRANCH.get(m.group("type").lower(), vocab.type_of(m.group("type"))):
            return
        tokens = [m.group("type")]
    found = False
    tokens = [t.strip("[]#") for t in tokens if t.strip("[]#")]
    for token in tokens:
        if not (TYPES_FROM_BRANCH.get(token.lower()) or vocab.type_of(token) or vocab.scope_of(token)[0]
                or vocab.qualifier_class(token)):
            return                                   # 'CI Failure: ...' is prose, not a label
    head = m.group("head") if "head" in m.groupdict() else None
    if head and norm(head) in vocab.scopes:          # 'Mission Control: ...' is one scope, not type + scope
        tokens = [head]
    lossless = True                                  # every label token survives in the rewritten prefix
    for token in tokens:
        t = TYPES_FROM_BRANCH.get(token.lower()) or vocab.type_of(token)
        canon = vocab.scope_of(token)[0]
        exact = norm(token) in vocab.scopes
        cls = vocab.qualifier_class(token)
        if t and not out.get("lead_type") and not exact:
            out["lead_type"] = t
            found = True
            lossless = lossless and norm(token) == t     # 'CI:' rewrites cleanly, 'wave' -> plan does not
        elif canon and (exact or not cls):
            if canon not in out["scopes"]:
                out["scopes"].append(canon)
            found = True
            lossless = lossless and exact and len(out["scopes"]) == 1
        elif cls:
            out["qualifiers"].append({"token": token, "class": cls})
            found = True
        else:
            lossless = False                         # a second type word such as 'wave' in 'DMAIC wave control'
    if found:
        out["lead_label"] = head or m.group("type")
        if lossless:
            out["subject"] = m.group("subject").strip()
        else:                                        # keep the whole label in the subject; qualifiers stay there too
            out["qualifiers"] = [q for q in out["qualifiers"] if q["token"] not in tokens]


TYPES_FROM_BRANCH = {"feature": "feat", "copilot": None, "bugfix": "fix", "hotfix": "fix"}


def lint(parsed, vocab):
    findings = []

    def add(code, detail=""):
        sev, msg = LINT_RULES[code]
        findings.append({"code": code, "severity": sev, "message": msg, "detail": detail})

    if not parsed["has_prefix"]:
        add("T001")
    else:
        canon = vocab.type_of(parsed["raw_type"])
        if canon is None:
            if vocab.scope_of(parsed["raw_type"])[0]:
                add("T007", parsed["raw_type"])
            else:
                add("T002", parsed["raw_type"])
        elif norm(parsed["raw_type"]) != canon:
            add("T003", "%s -> %s" % (parsed["raw_type"], canon))
        if not parsed["scopes"] and not parsed["unknown_scopes"] and not vocab.scope_of(parsed["raw_type"])[0]:
            add("T004")
        for raw in parsed["unknown_scopes"]:
            add("T005", raw)
        for raw, canon_scope in parsed["scope_aliases"]:
            add("T006", "%s -> %s" % (raw, canon_scope))
        if not parsed["subject"]:
            add("T010")
    if not parsed["has_prefix"] and parsed.get("lead_label"):
        add("T011", parsed["lead_label"])
    if parsed["tags"]:
        add("T008", ", ".join(parsed["tags"]))
    if len(parsed["subject"]) > 100:
        add("T009", str(len(parsed["subject"])))
    return findings


# -- classification ----------------------------------------------------------------------------

def classify_own(row, vocab):
    """Type and scopes from the row itself: title prefix, labels, branch name, keywords."""
    parsed = parse_title(row["title"], vocab)
    cls = {"type": None, "type_source": None, "scopes": [], "scope_source": None}
    if parsed["has_prefix"]:
        t = vocab.type_of(parsed["raw_type"])
        if t:
            cls["type"], cls["type_source"] = t, "title"
        scope_as_type = vocab.scope_of(parsed["raw_type"])[0] if not t else None
        scopes = parsed["scopes"] or ([scope_as_type] if scope_as_type else [])
        if not scopes and parsed["unknown_scopes"]:      # explicit but not in the vocabulary
            scopes = ["~" + parsed["unknown_scopes"][0]]
        if scopes:
            cls["scopes"], cls["scope_source"] = scopes, "title"
    else:
        if parsed.get("lead_type"):
            cls["type"], cls["type_source"] = parsed["lead_type"], "lead"
        if parsed["scopes"]:
            cls["scopes"], cls["scope_source"] = parsed["scopes"], "lead"
    labels = row.get("labels") or []
    if cls["type"] is None:
        for lab in labels:
            key = norm(lab.split(":", 1)[1]) if lab.lower().startswith("type:") else norm(lab)
            t = vocab.label_types.get(key) or (vocab.type_of(key) if lab.lower().startswith("type:") else None)
            if t:
                cls["type"], cls["type_source"] = t, "label"
                break
    if not cls["scopes"]:
        for lab in labels:
            key = lab.split(":", 1)[1] if ":" in lab and lab.split(":", 1)[0].lower() in ("scope", "family", "area") else lab
            canon = vocab.scope_of(key)[0]
            if canon:
                cls["scopes"], cls["scope_source"] = [canon], "label"
                break
    branch = row.get("branch") or ""
    if branch and (cls["type"] is None or not cls["scopes"]):
        m = BRANCH_RE.match(branch)
        if m and cls["type"] is None and vocab.type_of(m.group("type")):
            cls["type"], cls["type_source"] = vocab.type_of(m.group("type")), "branch"
        if not cls["scopes"]:
            found = vocab.infer_scopes(branch.replace("/", " "))
            if found:
                cls["scopes"], cls["scope_source"] = found[:2], "branch"
    text = parsed["subject"] + " " + " ".join(parsed["tags"])
    if cls["type"] is None:
        t = vocab.infer_type(text)
        if t:
            cls["type"], cls["type_source"] = t, "keyword"
    if not cls["scopes"]:
        found = vocab.infer_scopes(text)
        if found:
            cls["scopes"], cls["scope_source"] = found[:2], "keyword"
    return parsed, cls


def classify_all(rows, vocab):
    """Classify every row; issues missing a type or scope inherit recursively.

    Issue precedence: own title > label > closing PR > keyword > parent issue > sub-issues.
    Keyword and inherited results are kept apart so the plan can show the evidence chain.
    """
    by_key = {}
    for row in rows:
        parsed, own = classify_own(row, vocab)
        row["_parsed"], row["_own"] = parsed, own
        by_key[(row["repo"], row["kind"], row["number"])] = row
    children = {}
    for row in rows:
        if row["kind"] == "issue" and row.get("parent"):
            children.setdefault((row["repo"], row["parent"]), []).append(row)

    strong = ("title", "lead", "label", "branch")
    memo = {}

    def resolve(row, stack):
        key = (row["repo"], row["kind"], row["number"])
        if key in memo:
            return memo[key]
        own = dict(row["_own"])
        if row["kind"] == "pr" or key in stack:
            memo[key] = own
            return own
        stack = stack | {key}
        res = {"type": None, "type_source": None, "scopes": [], "scope_source": None}
        if own["type_source"] in strong:
            res["type"], res["type_source"] = own["type"], own["type_source"]
        if own["scope_source"] in strong:
            res["scopes"], res["scope_source"] = own["scopes"], own["scope_source"]
        # closing PRs (explicit titles are the strongest outside evidence)
        for num in row.get("closed_by_prs") or []:
            pr = by_key.get((row["repo"], "pr", num))
            if not pr:
                continue
            p = pr["_own"]
            if res["type"] is None and p["type_source"] in strong:
                res["type"], res["type_source"] = p["type"], "pr#%d" % num
            if not res["scopes"] and p["scope_source"] in strong:
                res["scopes"], res["scope_source"] = p["scopes"], "pr#%d" % num
        if res["type"] is None and own["type"]:
            res["type"], res["type_source"] = own["type"], own["type_source"]
        if not res["scopes"] and own["scopes"]:
            res["scopes"], res["scope_source"] = own["scopes"], own["scope_source"]
        parent = by_key.get((row["repo"], "issue", row.get("parent"))) if row.get("parent") else None
        if parent and (res["type"] is None or not res["scopes"]):
            p = resolve(parent, stack)
            if not res["scopes"] and p["scopes"]:
                res["scopes"], res["scope_source"] = p["scopes"], "parent#%d" % parent["number"]
            if res["type"] is None and p["type"]:
                res["type"], res["type_source"] = p["type"], "parent#%d" % parent["number"]
        kids = children.get((row["repo"], row["number"]), [])
        if kids and (res["type"] is None or not res["scopes"]):
            got = [resolve(k, stack) for k in kids]
            sc = Counter(s for g in got for s in g["scopes"][:1])
            ty = Counter(g["type"] for g in got if g["type"])
            if not res["scopes"] and sc:
                res["scopes"], res["scope_source"] = [sc.most_common(1)[0][0]], "children"
            if res["type"] is None and ty:
                res["type"], res["type_source"] = ty.most_common(1)[0][0], "children"
        memo[key] = res
        return res

    for row in rows:
        res = resolve(row, frozenset())
        row["_cls"] = res
        row["_lint"] = lint(row["_parsed"], vocab)
    return rows


def suggest_title(row, vocab):
    """Normalized title in the shared vocabulary, or None when type or scope is unresolved."""
    parsed, cls = row["_parsed"], row["_cls"]
    if not cls["type"] or not cls["scopes"]:
        return None
    quals = []
    for q in parsed["qualifiers"]:
        if q["token"] not in quals:
            quals.append(q["token"])
    for tag in parsed["tags"]:
        if tag not in quals and not vocab.qualifier_class(tag):
            quals.append(tag)
    scope = cls["scopes"][0].lstrip("~")
    inner = " ".join([scope] + quals)
    return "%s(%s)%s: %s" % (cls["type"], inner, "!" if parsed["breaking"] else "", parsed["subject"])


def levels(row, vocab):
    """The keys a row contributes to at each level of the hierarchy."""
    cls = row["_cls"]
    t = cls["type"] or "?"
    tf = vocab.type_family.get(cls["type"], "?")
    scope = cls["scopes"][0] if cls["scopes"] else "?"
    fam = vocab.scope_family.get(scope, "unmapped" if scope.startswith("~") else "?")
    quals = row["_parsed"]["qualifiers"]
    return {
        "type_family": tf,
        "type": t,
        "family": fam,
        "scope": scope,
        "prefix": "%s(%s)" % (t, scope),
        "family_prefix": "%s(%s)" % (t, fam),
        "qualifier_class": sorted(set(q["class"] for q in quals)) or ["-"],
        "qualifier": sorted(set(q["token"] for q in quals)) or ["-"],
    }
