"""Apply an issue alignment plan (from report.py) to GitHub. Dry run unless --apply is given.

    python apply_issues.py --plan out/issue_plan.json [--repos CODEX ...] [--labels-only] [--min-confidence strong] [--apply]

Creates any missing type:/family:/scope: labels, then edits each issue (labels added, never removed;
title replaced only when the plan proposes one). Prints one line per change.
"""
import argparse
import json
import os
import subprocess
import sys

RANK = {"none": 0, "inferred": 1, "strong": 2, "explicit": 3}
COLORS = {"type": "1d76db", "family": "0e8a16", "scope": "c5def5"}


def gh(args, apply):
    if not apply:
        return ""
    env = dict(os.environ)
    env.pop("GITHUB_TOKEN", None)
    env.pop("GH_TOKEN", None)
    proc = subprocess.run(["gh"] + args, capture_output=True, text=True, encoding="utf-8", env=env)
    if proc.returncode != 0:
        sys.stderr.write("FAILED gh %s: %s\n" % (" ".join(args[:4]), proc.stderr.strip()[:300]))
    return proc.stdout


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", default="out/issue_plan.json")
    ap.add_argument("--owner", default="GBOGEB")
    ap.add_argument("--repos", nargs="*")
    ap.add_argument("--labels-only", action="store_true")
    ap.add_argument("--min-confidence", default="strong", choices=list(RANK))
    ap.add_argument("--apply", action="store_true")
    args = ap.parse_args(argv)

    with open(args.plan, encoding="utf-8") as fh:
        plan = json.load(fh)["items"]
    if args.repos:
        plan = [p for p in plan if p["repo"] in args.repos]
    plan = [p for p in plan if RANK[p["confidence"]] >= RANK[args.min_confidence]]

    mode = "APPLY" if args.apply else "DRY-RUN"
    for repo in sorted(set(p["repo"] for p in plan)):
        names = sorted(set(l for p in plan if p["repo"] == repo for l in p["add_labels"]))
        existing = set()
        if args.apply:
            out = gh(["label", "list", "-R", "%s/%s" % (args.owner, repo), "--limit", "500", "--json", "name",
                      "--jq", ".[].name"], True)
            existing = set(out.split("\n"))
        for name in names:
            if name in existing:
                continue
            print("%s %s label create %s" % (mode, repo, name))
            gh(["label", "create", name, "-R", "%s/%s" % (args.owner, repo),
                "--color", COLORS.get(name.split(":")[0], "ededed"),
                "--description", "title taxonomy (%s)" % name.split(":")[0]], args.apply)

    n_title = n_label = 0
    for p in plan:
        cmd = ["issue", "edit", str(p["number"]), "-R", "%s/%s" % (args.owner, p["repo"])]
        if p["add_labels"]:
            cmd += ["--add-label", ",".join(p["add_labels"])]
            n_label += 1
        if p["new_title"] and not args.labels_only:
            cmd += ["--title", p["new_title"]]
            n_title += 1
        if len(cmd) == 5:
            continue
        if args.apply:   # the plan is a snapshot: skip an issue someone retitled or closed since
            now = json.loads(gh(["issue", "view", str(p["number"]), "-R", "%s/%s" % (args.owner, p["repo"]),
                                 "--json", "title,state"], True) or "{}")
            if now.get("title") != p["title"] or now.get("state") != "OPEN":
                print("SKIP %s#%d changed since the pulse: %r" % (p["repo"], p["number"], now))
                continue
        print("%s %s#%d %s%s" % (mode, p["repo"], p["number"],
                                 ("labels+" + ",".join(p["add_labels"]) + " ") if p["add_labels"] else "",
                                 ("title: %r -> %r" % (p["title"], p["new_title"])) if (p["new_title"] and not args.labels_only) else ""))
        gh(cmd, args.apply)
    print("%s: %d issues, %d label edits, %d retitles" % (mode, len(plan), n_label, n_title))


if __name__ == "__main__":
    main()
