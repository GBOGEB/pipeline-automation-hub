"""Per-family CI view for the title census, built on the PAH owners rather than re-implementing them:

  * red_trace.classify()        (mission-control/gogreen/red_trace/red_trace.py) classifies each PR's sequence of
                                 combined check states over its last 10 commits: EVERRED, GREEN_TO_RED, RED_TO_GREEN,
                                 FLAKY, STABLE_GREEN, UNKNOWN_NO_TERMINAL. The unit is a PR, not a default-branch workflow.
  * cicd_dag.everred_metrics()  (mission-control/jade_temple/tools/cicd_dag.py) turns those class counts into
                                 everred_ratio, recovery_rate, flake_rate, red_now and red-now median age, per family.
  * RED_TRACE_FEDERATION_N8.json (owner data) gives each workflow's default-branch class for the five core repos.
  * site/cicd_dag_crosswalk.csv  (owner output) maps workflow files to DAG nodes: SIPOC letter, type, DMAIC phase,
                                 layer and blob OID bindings.

    python ci_census.py --pah <pipeline-automation-hub checkout> [--raw data/raw.json --checks data/checks.json --out out]
"""
import argparse
import csv
import hashlib
import importlib.util
import json
import os
import re
from collections import Counter, defaultdict
from datetime import datetime

MAJOR = 10                   # a family is "major" with more than this many titles (PRs + issues), as asked
STATE_TO_CONCLUSION = {"success": "success", "failure": "failure", "error": "failure"}   # pending/expected: non-terminal


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def day(ts):
    return datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")


def first_oid(binding):
    m = re.match(r"([0-9a-f]{40}):", binding or "")
    return m.group(1) if m else ""


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--pah", required=True)
    ap.add_argument("--raw", default="data/raw.json")
    ap.add_argument("--checks", default="data/checks.json")
    ap.add_argument("--out", default="out")
    args = ap.parse_args(argv)
    mc = os.path.join(args.pah, "mission-control")
    red_trace = load("red_trace", os.path.join(mc, "gogreen", "red_trace", "red_trace.py"))
    cicd_dag = load("cicd_dag", os.path.join(mc, "jade_temple", "tools", "cicd_dag.py"))
    with open(os.path.join(mc, "jade_temple", "data", "RED_TRACE_FEDERATION_N8.json"), encoding="utf-8") as fh:
        fed = json.load(fh)
    with open(os.path.join(mc, "jade_temple", "site", "cicd_dag_crosswalk.csv"), encoding="utf-8") as fh:
        dag = list(csv.DictReader(fh))
    with open(args.checks, encoding="utf-8") as fh:
        checks = json.load(fh)
    with open(os.path.join(args.out, "dash", "titles.json"), encoding="utf-8") as fh:
        titles = {(t["repo"], t["kind"], t["number"]): t for t in json.load(fh)}
    pulse = day(checks["pulse"])

    # owner default-branch class per (repo, workflow path); traced repos without a non-green entry are not red
    wf_class, traced_repos = {}, set()
    for r in fed["repositories"]:
        repo = r["repository"].split("/")[-1]
        traced_repos.add(repo)
        for w in r["non_green"]:
            wf_class[(repo, w["path"])] = w["class"]
    # DAG nodes per workflow path (repo scope first, TOTAL scope as fallback)
    dag_by_path = defaultdict(list)
    for n in dag:
        text = " ".join(n.values())
        for path in set(re.findall(r"\.github/workflows/[\w.-]+", text)):
            scope = n["scope"].split(":", 1)[1] if n["scope"].startswith("REPO:") else n["scope"]
            dag_by_path[(scope, path)].append(n)

    prs = []
    for rep in checks["repos"]:
        for p in rep["prs"]:
            t = titles.get((rep["repo"], "pr", p["number"]))
            if not t:
                continue
            seq = [{"conclusion": STATE_TO_CONCLUSION.get(c["state"], c["state"] or "pending"), "sha": c["oid"],
                    "run_id": None, "at": c["at"]} for c in p["commits"]]
            cls = red_trace.classify(seq)
            reds = [c for c in p["commits"] if STATE_TO_CONCLUSION.get(c["state"]) == "failure"]
            sig = sorted(set(s["workflow"] or s["path"] or "?" for s in p["suites"]))
            prs.append({
                "repo": rep["repo"], "number": p["number"], "family": t["family"], "scope": t["scope"],
                "state": t["state"], "created": t["created"], "title": t["title"], "head_oid": p["head_oid"],
                "commits_total": p["commits_total"], "commits_seen": len(p["commits"]),
                "ci_class": cls["class"], "ci_current": cls.get("current", ""), "ci_flips": len(cls["flips"]),
                "ci_last": p["commits"][-1]["state"] if p["commits"] else "",
                "red_age_days": round((pulse - day(reds[-1]["at"])).total_seconds() / 86400.0, 2) if reds and cls.get("current") == "RED" else None,
                "signature": hashlib.sha1("|".join(sig).encode("utf-8")).hexdigest()[:10] if sig else "",
                "signature_names": " + ".join(sig), "suites": p["suites"],
            })

    family_n = Counter(t["family"] for t in titles.values())
    major = {f for f, n in family_n.items() if n > MAJOR}

    # per (repo|ALL, family): a red_trace-shaped document so cicd_dag.everred_metrics() computes the rates
    groups = defaultdict(list)
    for p in prs:
        if p["family"] in major:
            for repo in (p["repo"], "ALL"):
                groups[(repo, p["family"])].append(p)
    family_rows = []
    for (repo, fam), items in sorted(groups.items()):
        terminal = [p for p in items if p["ci_class"] != "UNKNOWN_NO_TERMINAL"]
        counts = Counter(p["ci_class"] for p in terminal)
        non_green = [{"age_days": p["red_age_days"] or 0.0, "current": p["ci_current"]} for p in terminal if p["ci_current"] == "RED"]
        red_open = sum(1 for p in terminal if p["ci_current"] == "RED" and p["state"] == "open")
        doc = {"repositories": [{"repository": fam, "counts": dict(counts), "workflows_traced": len(terminal),
                                 "non_green": non_green, "shared_break_roots": [], "currently_red_stale": len(non_green) - red_open}],
               "totals": {"workflows": len(terminal), "runs": sum(p["commits_seen"] for p in items), "red_fresh": red_open,
                          "red_stale": len(non_green) - red_open, "pinned_red": 0}}
        block = cicd_dag.everred_metrics(doc)["total"]
        last = max(items, key=lambda p: (p["created"], p["number"]))
        # which workflow keeps red-now PRs red: count red PRs failing each workflow on their head commit
        red_prs = [p for p in terminal if p["ci_current"] == "RED"]
        drivers = Counter(w for p in red_prs for w in sorted(set(s["workflow"] or s["path"] or "?" for s in p["suites"]
                                                                 if s["conclusion"] in ("failure", "timed_out", "startup_failure"))))
        top_driver, top_n = min(drivers.items(), key=lambda kv: (-kv[1], kv[0])) if drivers else ("", 0)   # ties: by name
        family_rows.append({
            "id": "%s|%s" % (repo, fam), "repo": repo, "family": fam, "prs": len(items), "prs_with_ci": len(terminal),
            "everred": block["everred"], "green_to_red": block["green_to_red"], "red_to_green": block["red_to_green"],
            "flaky": block["flaky"], "stable_green": counts.get("STABLE_GREEN", 0),
            "no_terminal": len(items) - len(terminal), "everred_ratio": block["everred_ratio"],
            "recovery_rate": block["recovery_rate"], "flake_rate": block["flake_rate"], "red_now": block["red_now"],
            "red_now_open": red_open, "red_now_median_age_days": block["red_now_median_age_days"],
            "last_pr": last["number"], "last_pr_repo": last["repo"], "last_pr_state": last["state"],
            "last_pr_ci": last["ci_last"], "last_pr_class": last["ci_class"], "last_pr_oid": last["head_oid"],
            "last_pr_title": last["title"],
            "red_prs": len(red_prs), "top_red_driver": top_driver, "top_red_driver_prs": top_n,
            "top_red_driver_share": round(top_n / float(len(red_prs)), 4) if red_prs else None,
        })

    # checks (workflows) per family: head-commit outcomes, owner default-branch class, DAG / SIPOC / OID binding
    agg = defaultdict(lambda: Counter())
    meta = {}
    for p in prs:
        if p["family"] not in major:
            continue
        for s in p["suites"]:
            key_wf = s["path"] or ("(app) " + (s["workflow"] or "?"))
            for repo in (p["repo"], "ALL"):
                c = agg[(repo, p["family"], p["repo"], key_wf)]
                c["runs"] += 1
                c[s["conclusion"] if s["conclusion"] in ("success", "failure", "cancelled", "skipped") else "other"] += 1
            meta[(p["repo"], key_wf)] = s["workflow"] or ""
    check_rows = []
    for (repo, fam, wf_repo, path), c in sorted(agg.items()):
        nodes = dag_by_path.get((wf_repo, path), []) + dag_by_path.get(("TOTAL", path), [])
        default_class = wf_class.get((wf_repo, path)) or ("not red on default branch" if wf_repo in traced_repos and path.startswith(".github") else "not traced")
        check_rows.append({
            "id": "%s|%s|%s|%s" % (repo, fam, wf_repo, path), "repo": repo, "family": fam, "workflow_repo": wf_repo,
            "path": path, "workflow": meta.get((wf_repo, path), ""), "runs": c["runs"], "success": c["success"],
            "failure": c["failure"], "cancelled": c["cancelled"], "skipped": c["skipped"], "other": c["other"],
            "failure_share": round(c["failure"] / float(c["runs"]), 4) if c["runs"] else None,
            "default_branch_class": default_class,
            "dag_nodes": " ".join(n["node_id"] for n in nodes), "sipoc": " ".join(sorted(set(n["sipoc"] for n in nodes))),
            "dag_types": " ".join(sorted(set(n["type"] for n in nodes))), "dmaic": " ".join(sorted(set(n["dmaic_phase"] for n in nodes if n["dmaic_phase"]))),
            "dag_layer": min([int(n["layer"]) for n in nodes if n["layer"].isdigit()] or [-1]),
            "oid": next((first_oid(b) for n in nodes for b in n["oid_bindings"].split("|") if path in b), ""),
        })

    # activity signatures: PRs that ran exactly the same set of workflows on their head commit
    sig_rows = []
    sigs = defaultdict(list)
    for p in prs:
        if p["family"] in major and p["signature"]:
            for repo in (p["repo"], "ALL"):
                sigs[(repo, p["family"], p["signature"])].append(p)
    for (repo, fam, sig), items in sorted(sigs.items()):
        if len(items) < 2:
            continue
        cls = Counter(p["ci_class"] for p in items)
        sig_rows.append({"id": "%s|%s|%s" % (repo, fam, sig), "repo": repo, "family": fam, "signature": sig,
                         "workflows": items[0]["signature_names"], "n_workflows": items[0]["signature_names"].count(" + ") + 1,
                         "prs": len(items), "red_now": sum(1 for p in items if p["ci_current"] == "RED"),
                         "classes": ", ".join("%s %d" % kv for kv in cls.most_common())})

    pr_rows = [{k: v for k, v in p.items() if k != "suites"} for p in prs]
    os.makedirs(os.path.join(args.out, "dash"), exist_ok=True)
    for name, rows in (("ci_family", family_rows), ("ci_checks", check_rows), ("ci_signatures", sig_rows), ("ci_prs", pr_rows)):
        with open(os.path.join(args.out, name + ".csv"), "w", encoding="utf-8", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()), lineterminator="\n")
            w.writeheader()
            w.writerows(rows)
        if name != "ci_prs":
            with open(os.path.join(args.out, "dash", name + ".json"), "w", encoding="utf-8", newline="\n") as fh:
                json.dump(rows, fh, ensure_ascii=False, separators=(",", ":"))
    # head OID and CI class onto the titles dataset (PRs only)
    by_key = {(p["repo"], p["number"]): p for p in prs}
    with open(os.path.join(args.out, "dash", "titles.json"), encoding="utf-8") as fh:
        tl = json.load(fh)
    for t in tl:
        p = by_key.get((t["repo"], t["number"])) if t["kind"] == "pr" else None
        t["head_oid"], t["ci_class"], t["ci_last"] = (p["head_oid"], p["ci_class"], p["ci_last"]) if p else ("", "", "")
    with open(os.path.join(args.out, "dash", "titles.json"), "w", encoding="utf-8", newline="\n") as fh:
        json.dump(tl, fh, ensure_ascii=False, separators=(",", ":"))
    print("major families %d; PRs classified %d; family rows %d; check rows %d; signatures %d"
          % (len(major), len(prs), len(family_rows), len(check_rows), len(sig_rows)))


if __name__ == "__main__":
    main()
