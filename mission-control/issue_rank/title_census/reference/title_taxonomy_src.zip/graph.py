"""PR / issue crosswalk edges from a fetch pulse. Counts only: ranking metrics (PageRank, betweenness,
unblock pressure) belong to mission-control/issue_rank/issue_rank.py and are not recomputed here.

Edge types (src -> dst):
  closes    PR -> issue      GitHub closing references, from both the PR and the issue side
  parent    issue -> issue   sub-issue hierarchy (parent -> child)
  mentions  any -> any       '#123', 'Repo#123' or 'PR123' written in a title, resolved inside the pulse
"""
import re

REF_RE = re.compile(r"(?<![\w/])(?:(?P<repo>[A-Za-z][\w.-]*)#|#|\bPR-?)(?P<num>\d{1,6})\b")


def node_id(repo, kind, number):
    return "%s/%s/%s" % (repo, kind, number)


def edges(rows):
    """Return the deduplicated edge list for rows from one pulse."""
    index = {}
    for r in rows:
        index[(r["repo"], r["number"])] = r          # PR and issue numbers share one sequence per repo
    repos = {r["repo"].lower(): r["repo"] for r in rows}
    out = {}

    def add(kind, src, dst, evidence):
        if src is dst:
            return
        key = (kind, src["repo"], src["number"], dst["repo"], dst["number"])
        if key in out:
            return
        out[key] = {
            "id": "%s:%s>%s" % (kind, node_id(src["repo"], src["kind"], src["number"]),
                                node_id(dst["repo"], dst["kind"], dst["number"])),
            "type": kind, "evidence": evidence,
            "src": node_id(src["repo"], src["kind"], src["number"]),
            "dst": node_id(dst["repo"], dst["kind"], dst["number"]),
            "src_repo": src["repo"], "dst_repo": dst["repo"], "src_kind": src["kind"], "dst_kind": dst["kind"],
            "cross_repo": src["repo"] != dst["repo"],
        }

    for r in rows:
        if r["kind"] == "pr":
            for ref in r.get("closes") or []:
                dst = index.get((ref["repo"], ref["number"]))
                if dst and dst["kind"] == "issue":
                    add("closes", r, dst, "closingIssuesReferences")
        else:
            refs = r.get("closed_by_refs")
            if refs is None:                          # older pulses: same-repo numbers only
                refs = [{"repo": r["repo"], "number": n} for n in r.get("closed_by_prs") or []]
            for ref in refs:
                src = index.get((ref["repo"], ref["number"]))
                if src and src["kind"] == "pr":
                    add("closes", src, r, "closedByPullRequestsReferences")
            pref = r.get("parent_ref") or ({"repo": r["repo"], "number": r["parent"]} if r.get("parent") else None)
            if pref:
                parent = index.get((pref["repo"], pref["number"]))
                if parent:
                    add("parent", parent, r, "parent")
        for m in REF_RE.finditer(r["title"]):
            repo = repos.get((m.group("repo") or "").lower(), r["repo"]) if m.group("repo") else r["repo"]
            if m.group("repo") and m.group("repo").lower() not in repos:
                continue                              # 'GOV-001#3' style tokens that name no repo in the pulse
            dst = index.get((repo, int(m.group("num"))))
            if dst:
                add("mentions", r, dst, "title")
    return list(out.values())
