"""PR / issue crosswalk edges from a fetch pulse. Counts only: ranking metrics (PageRank, betweenness,
unblock pressure) belong to mission-control/issue_rank/issue_rank.py and are not recomputed here.

One edge per ordered pair (src -> dst). When several sources report the same pair, the edge takes the
strongest type and lists every source in `evidence`:

  closes    PR -> issue      GitHub closing references (both sides), a timeline cross-reference that will
                             close the target, or 'Closes/Fixes/Resolves #n' in a PR body
  parent    issue -> issue   sub-issue hierarchy (parent -> child)
  mentions  any -> any       '#123', 'Repo#123' or 'PR123' written in a title
  refs      any -> any       a reference in a PR or issue body ('Refs #n', 'ABACUS#12', a GitHub URL, ...)
  xref      any -> any       a GitHub timeline cross-reference (the source mentioned the target in its body,
                             a comment or a commit)

Only references that resolve to a PR or issue inside the pulse become edges.
"""
import re

PRIORITY = ["closes", "parent", "mentions", "refs", "xref"]
TITLE_REF_RE = re.compile(r"(?<![\w/])(?:(?P<repo>[A-Za-z][\w.-]*)#|#|\bPR-?)(?P<num>\d{1,6})\b")
CLOSING_RE = re.compile(r"\b(?:close[sd]?|fix(?:e[sd])?|resolve[sd]?)\s*:?\s*$", re.I)
FENCE_RE = re.compile(r"```.*?```|`[^`\n]*`|<!--.*?-->", re.S)
BODY_REF_RE = re.compile(
    r"https?://github\.com/(?P<uowner>[\w.-]+)/(?P<urepo>[\w.-]+)/(?:issues|pull)/(?P<unum>\d+)"
    r"|(?<![\w/#])(?:(?P<owner>[\w.-]+)/)?(?P<repo>[A-Za-z][\w.-]*)?#(?P<num>\d{1,6})\b")


def node_id(repo, kind, number):
    return "%s/%s/%s" % (repo, kind, number)


def body_refs(body, owner, repo):
    """References in a PR / issue body, owner-local only: [{repo, number, closing}], code and HTML comments ignored."""
    text = FENCE_RE.sub(" ", body or "")
    out = {}
    for m in BODY_REF_RE.finditer(text):
        if m.group("unum"):
            if m.group("uowner").lower() != owner.lower():
                continue
            target = (m.group("urepo"), int(m.group("unum")))
        else:
            if m.group("owner") and m.group("owner").lower() != owner.lower():
                continue
            target = (m.group("repo") or repo, int(m.group("num")))
        closing = bool(CLOSING_RE.search(text[max(0, m.start() - 20):m.start()]))
        key = (target[0].lower(), target[1])
        prev = out.get(key)
        out[key] = {"repo": target[0], "number": target[1], "closing": closing or bool(prev and prev["closing"])}
    return list(out.values())


def edges(rows):
    """Return the merged edge list for rows from one pulse."""
    index = {}
    for r in rows:
        index[(r["repo"].lower(), r["number"])] = r   # PR and issue numbers share one sequence per repo
    repos = {r["repo"].lower() for r in rows}
    out = {}

    def find(repo, number):
        return index.get(((repo or "").lower(), number))

    def add(kind, src, dst, evidence):
        if not src or not dst or src is dst:
            return
        s, d = node_id(src["repo"], src["kind"], src["number"]), node_id(dst["repo"], dst["kind"], dst["number"])
        e = out.get((s, d))
        if e is None:
            e = out[(s, d)] = {"id": "%s>%s" % (s, d), "type": kind, "evidence": [], "src": s, "dst": d,
                               "src_repo": src["repo"], "dst_repo": dst["repo"], "src_kind": src["kind"],
                               "dst_kind": dst["kind"], "cross_repo": src["repo"] != dst["repo"]}
        elif PRIORITY.index(kind) < PRIORITY.index(e["type"]):
            e["type"] = kind
        if evidence not in e["evidence"]:
            e["evidence"].append(evidence)

    for r in rows:
        if r["kind"] == "pr":
            for ref in r.get("closes") or []:
                dst = find(ref["repo"], ref["number"])
                if dst and dst["kind"] == "issue":
                    add("closes", r, dst, "closingIssuesReferences")
        else:
            refs = r.get("closed_by_refs")
            if refs is None:                          # older pulses: same-repo numbers only
                refs = [{"repo": r["repo"], "number": n} for n in r.get("closed_by_prs") or []]
            for ref in refs:
                src = find(ref["repo"], ref["number"])
                if src and src["kind"] == "pr":
                    add("closes", src, r, "closedByPullRequestsReferences")
            pref = r.get("parent_ref") or ({"repo": r["repo"], "number": r["parent"]} if r.get("parent") else None)
            if pref:
                add("parent", find(pref["repo"], pref["number"]), r, "parent")
        for m in TITLE_REF_RE.finditer(r["title"]):
            if m.group("repo") and m.group("repo").lower() not in repos:
                continue                              # 'GOV-001#3' style tokens that name no repo in the pulse
            add("mentions", r, find(m.group("repo") or r["repo"], int(m.group("num"))), "title")
        for ref in r.get("body_refs") or []:
            dst = find(ref["repo"], ref["number"])
            closing = ref.get("closing") and r["kind"] == "pr" and dst is not None and dst["kind"] == "issue"
            add("closes" if closing else "refs", r, dst, "body keyword" if ref.get("closing") else "body")
        for x in r.get("xrefs") or []:
            src = find(x["repo"], x["number"])
            closing = x.get("will_close") and src is not None and src["kind"] == "pr" and r["kind"] == "issue"
            add("closes" if closing else "xref", src, r, "timeline")
    result = []
    for e in out.values():
        e["evidence"] = "+".join(e["evidence"])
        result.append(e)
    return result
