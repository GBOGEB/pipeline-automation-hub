"""Fetch per-PR CI evidence for the title census (read-only GitHub GraphQL via `gh`).

For every PR: the head commit OID, the last 10 commits with their combined check state (oldest first), and the
check suites on the head commit with their workflow file path and conclusion. Per-repo files are cached in
data/checks/ (--resume reuses them).

    python fetch_checks.py --raw data/raw.json --out data/checks.json [--resume]
"""
import argparse
import json
import os
import sys
from datetime import datetime, timezone

from fetch import gh_graphql

QUERY = """
query($owner:String!, $name:String!, $cursor:String) {
  rateLimit { cost remaining resetAt }
  repository(owner:$owner, name:$name) {
    pullRequests(first:50, after:$cursor, orderBy:{field:CREATED_AT, direction:ASC}) {
      pageInfo { hasNextPage endCursor }
      nodes {
        number headRefOid
        commits(last:10) { totalCount nodes { commit { oid committedDate statusCheckRollup { state } } } }
        head: commits(last:1) { nodes { commit { checkSuites(first:30) { nodes {
          conclusion status workflowRun { databaseId file { path } workflow { name } } } } } } }
      }
    }
  }
}"""


def fetch_repo(owner, name):
    rows, cursor, cost = [], None, 0
    while True:
        data = gh_graphql(QUERY, owner=owner, name=name, cursor=cursor)
        cost += data["rateLimit"]["cost"]
        block = data["repository"]["pullRequests"]
        for n in block["nodes"]:
            head = (n.get("head") or {}).get("nodes") or []
            suites = []
            for s in ((head[0]["commit"].get("checkSuites") or {}).get("nodes") or []) if head else []:
                run = s.get("workflowRun") or {}
                if not run:
                    continue                                   # non-Actions apps (e.g. Dependabot alerts)
                suites.append({"path": (run.get("file") or {}).get("path"), "workflow": (run.get("workflow") or {}).get("name"),
                               "run_id": run.get("databaseId"), "conclusion": (s.get("conclusion") or s.get("status") or "").lower()})
            rows.append({
                "number": n["number"], "head_oid": n["headRefOid"], "commits_total": n["commits"]["totalCount"],
                "commits": [{"oid": c["commit"]["oid"], "at": c["commit"]["committedDate"],
                             "state": ((c["commit"].get("statusCheckRollup") or {}).get("state") or "").lower()}
                            for c in n["commits"]["nodes"]],
                "suites": suites,
            })
        if not block["pageInfo"]["hasNextPage"]:
            return {"repo": name, "prs": rows, "cost": cost, "remaining": data["rateLimit"]["remaining"]}
        cursor = block["pageInfo"]["endCursor"]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/raw.json")
    ap.add_argument("--out", default="data/checks.json")
    ap.add_argument("--repos", nargs="*")
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args(argv)
    with open(args.raw, encoding="utf-8") as fh:
        raw = json.load(fh)
    repos = args.repos or [r["repo"] for r in raw["repos"] if any(x["kind"] == "pr" for x in r["rows"])]
    cache = os.path.join(os.path.dirname(args.out) or ".", "checks")
    os.makedirs(cache, exist_ok=True)
    out = {"schema": "gbogeb.title-taxonomy.checks/1.0", "owner": raw["owner"], "pulse": raw["fetched_at"],
           "fetched_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "repos": []}
    for name in repos:
        path = os.path.join(cache, name + ".json")
        if args.resume and os.path.exists(path):
            with open(path, encoding="utf-8") as fh:
                out["repos"].append(json.load(fh))
            continue
        rep = fetch_repo(raw["owner"], name)
        sys.stderr.write("checks %s: %d PRs, cost %d, remaining %d\n" % (name, len(rep["prs"]), rep["cost"], rep["remaining"]))
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(rep, fh)
        out["repos"].append(rep)
    with open(args.out, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(out, fh)
    sys.stderr.write("wrote %s: %d repos\n" % (args.out, len(out["repos"])))


if __name__ == "__main__":
    main()
