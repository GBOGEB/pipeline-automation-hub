"""Build the title-taxonomy census from a fetch pulse: per-repo and total breakdowns at every level.

    python report.py --raw data/raw.json --out out [--asof 2026-10-26]

Writes (all LF, UTF-8):
  out/census.json       gbogeb.title-taxonomy.census/1.0 (pulse SHAs, level stats, series, conformance, inventory)
  out/rows.csv          one row per PR / issue with its parsed + resolved levels and lint codes
  out/stats.csv         long form: repo|ALL x kind x level x key -> n, share, rank, open/closed/merged, 30d trend
  out/timeseries.csv    monthly counts and running totals per level key
  out/conformance.csv   monthly explicit / lint-clean / resolved rates
  out/keywords.md       the vocabulary with observed counts, unmapped scopes and unknown types
  out/issue_plan.json   dry-run plan to align issue titles and labels (apply with apply_issues.py)
  out/issue_plan.md     the same plan, readable
"""
import argparse
import csv
import hashlib
import json
import os
from collections import Counter, defaultdict
from datetime import datetime, timedelta

import taxonomy as T

LEVELS = ["type_family", "type", "family", "scope", "prefix", "family_prefix", "qualifier_class", "qualifier"]
BOT_LOGINS = {"github-actions", "dependabot", "copilot-swe-agent", "renovate"}
STRONG = ("title", "lead", "label", "branch")


def day(ts):
    return datetime.strptime(ts[:10], "%Y-%m-%d") if ts else None


def is_bot(login):
    login = (login or "").lower()
    return login in BOT_LOGINS or login.endswith("[bot]") or login.endswith("-bot")


def confidence(cls):
    srcs = [cls["type_source"] or "", cls["scope_source"] or ""]
    if not cls["type"] or not cls["scopes"]:
        return "none"
    if all(s == "title" for s in srcs):
        return "explicit"
    if all(s in STRONG or s.startswith("pr#") for s in srcs):
        return "strong"
    return "inferred"


def median(values):
    values = sorted(values)
    if not values:
        return None
    mid = len(values) // 2
    return values[mid] if len(values) % 2 else (values[mid - 1] + values[mid]) / 2.0


def level_keys(row, vocab):
    out = []
    for level, keys in T.levels(row, vocab).items():
        for key in (keys if isinstance(keys, list) else [keys]):
            out.append((level, key))
    return out


def build(raw, vocab, asof):
    rows = [r for repo in raw["repos"] for r in repo["rows"]]
    T.classify_all(rows, vocab)
    for r in rows:
        r["_levels"] = level_keys(r, vocab)
        r["_conf"] = confidence(r["_cls"])
        r["_sev"] = max([T.SEVERITY[f["severity"]] for f in r["_lint"]] or [0])
        r["_suggest"] = T.suggest_title(r, vocab)

    window_start = asof - timedelta(days=30)
    prev_start = asof - timedelta(days=60)

    # -- level stats, per repo and ALL, per kind and all kinds --
    acc = defaultdict(lambda: {"n": 0, "open": 0, "closed": 0, "merged": 0, "n_30d": 0, "n_prev_30d": 0,
                               "ttc": [], "first": None, "last": None})
    totals = Counter()
    for r in rows:
        created = day(r["created"])
        for repo in (r["repo"], "ALL"):
            for kind in (r["kind"], "all"):
                totals[(repo, kind)] += 1
                for level, key in r["_levels"]:
                    a = acc[(repo, kind, level, key)]
                    a["n"] += 1
                    a[r["state"] if r["state"] in ("open", "closed", "merged") else "closed"] += 1
                    if created >= window_start:
                        a["n_30d"] += 1
                    elif created >= prev_start:
                        a["n_prev_30d"] += 1
                    if r["closed"]:
                        a["ttc"].append((day(r["closed"]) - created).days)
                    a["first"] = min(a["first"] or r["created"], r["created"])
                    a["last"] = max(a["last"] or r["created"], r["created"])
    level_total = Counter()
    for (repo, kind, level, key), a in acc.items():
        level_total[(repo, kind, level)] += a["n"]
    stats = []
    for (repo, kind, level, key), a in acc.items():
        stats.append({
            "repo": repo, "kind": kind, "level": level, "key": key, "n": a["n"],
            "share": round(a["n"] / float(level_total[(repo, kind, level)]), 4),
            "open": a["open"], "closed": a["closed"], "merged": a["merged"],
            "n_30d": a["n_30d"], "n_prev_30d": a["n_prev_30d"], "trend_30d": a["n_30d"] - a["n_prev_30d"],
            "median_days_to_close": median(a["ttc"]), "first_seen": a["first"][:10], "last_seen": a["last"][:10],
        })
    stats.sort(key=lambda s: (s["repo"] != "ALL", s["repo"], s["kind"], LEVELS.index(s["level"]), -s["n"], s["key"]))
    rank = Counter()
    for s in stats:
        rank[(s["repo"], s["kind"], s["level"])] += 1
        s["rank"] = rank[(s["repo"], s["kind"], s["level"])]

    # -- monthly series with running totals --
    series_acc = Counter()
    for r in rows:
        month = r["created"][:7]
        for repo in (r["repo"], "ALL"):
            for kind in (r["kind"], "all"):
                for level, key in r["_levels"]:
                    if level in ("type_family", "type", "family", "prefix", "family_prefix"):
                        series_acc[(repo, kind, level, key, month)] += 1
    running = Counter()
    series = []
    for (repo, kind, level, key, month) in sorted(series_acc):
        n = series_acc[(repo, kind, level, key, month)]
        running[(repo, kind, level, key)] += n
        series.append({"repo": repo, "kind": kind, "level": level, "key": key, "month": month,
                       "n": n, "cum_n": running[(repo, kind, level, key)]})

    # -- conformance per month --
    conf_acc = defaultdict(Counter)
    for r in rows:
        explicit = r["_parsed"]["has_prefix"] and vocab.type_of(r["_parsed"]["raw_type"] or "") is not None
        for repo in (r["repo"], "ALL"):
            for kind in (r["kind"], "all"):
                for month in (r["created"][:7], "ALL"):
                    c = conf_acc[(repo, kind, month)]
                    c["n"] += 1
                    c["explicit"] += int(explicit)
                    c["clean"] += int(r["_sev"] < T.SEVERITY["warning"])
                    c["resolved"] += int(r["_conf"] != "none")
    conformance = []
    for (repo, kind, month), c in sorted(conf_acc.items()):
        conformance.append({"repo": repo, "kind": kind, "month": month, "n": c["n"],
                            "explicit": c["explicit"], "clean": c["clean"], "resolved": c["resolved"],
                            "explicit_rate": round(c["explicit"] / float(c["n"]), 4),
                            "clean_rate": round(c["clean"] / float(c["n"]), 4),
                            "resolved_rate": round(c["resolved"] / float(c["n"]), 4)})

    return rows, stats, series, conformance


def inventory(rows, vocab):
    """Every keyword: canonical scopes with their aliases and the raw spellings actually seen."""
    seen_scope = defaultdict(Counter)       # canonical scope -> raw spelling -> n
    by_repo = defaultdict(Counter)          # canonical scope -> repo -> n
    unknown_scope = defaultdict(Counter)
    unknown_type = defaultdict(Counter)
    raw_type = defaultdict(Counter)
    lint_codes = defaultdict(Counter)
    for r in rows:
        p = r["_parsed"]
        for code in set(f["code"] for f in r["_lint"]):
            lint_codes[code][r["repo"]] += 1
        if not p["has_prefix"]:
            continue
        t = vocab.type_of(p["raw_type"])
        if t:
            raw_type[t][p["raw_type"]] += 1
        elif not vocab.scope_of(p["raw_type"])[0]:
            unknown_type[p["raw_type"]][r["repo"]] += 1
        if p["raw_scope"]:
            for part in p["raw_scope"].split(","):
                words = [w for w in part.split() if not vocab.qualifier_class(w)]
                if not words:
                    continue
                canon = vocab.scope_of(" ".join(words))[0] or vocab.scope_of(words[0])[0]
                if canon:
                    seen_scope[canon][" ".join(words)] += 1
                    by_repo[canon][r["repo"]] += 1
                else:
                    unknown_scope[T.norm(" ".join(words))][r["repo"]] += 1
        elif not t and vocab.scope_of(p["raw_type"])[0]:
            canon = vocab.scope_of(p["raw_type"])[0]
            seen_scope[canon][p["raw_type"] + " (as type)"] += 1
            by_repo[canon][r["repo"]] += 1
    families = []
    for fam, spec in vocab.raw["families"].items():
        scopes = []
        for canon, aliases in spec["scopes"].items():
            scopes.append({"scope": canon, "aliases": [a.lstrip("=") for a in aliases],
                           "explicit_only": [a.lstrip("=") for a in aliases if a.startswith("=")],
                           "seen": dict(seen_scope[canon].most_common()), "by_repo": dict(by_repo[canon].most_common()),
                           "n_explicit": sum(seen_scope[canon].values())})
        families.append({"family": fam, "label": spec.get("label", fam), "scopes": scopes})
    types = [{"type": t, "family": spec["family"], "aliases": spec["aliases"], "seen": dict(raw_type[t].most_common())}
             for t, spec in vocab.raw["types"].items()]
    return {
        "types": types, "families": families,
        "qualifier_classes": [q["class"] for q in vocab.raw["qualifiers"]],
        "unmapped_scopes": sorted(({"scope": k, "n": sum(v.values()), "by_repo": dict(v)} for k, v in unknown_scope.items()),
                                  key=lambda x: -x["n"]),
        "unknown_types": sorted(({"type": k, "n": sum(v.values()), "by_repo": dict(v)} for k, v in unknown_type.items()),
                                key=lambda x: -x["n"]),
        "lint_codes": {code: {"severity": T.LINT_RULES[code][0], "message": T.LINT_RULES[code][1],
                              "n": sum(lint_codes[code].values()), "by_repo": dict(lint_codes[code])}
                       for code in sorted(lint_codes)},
    }


def issue_plan(rows, vocab):
    """Dry-run alignment of issues to the shared vocabulary.

    Labels (type:<t>, family:<f>, scope:<s>) are proposed for every open issue with a resolved
    field. Titles are proposed only for open, human-authored issues whose classification is
    explicit or strong, or inferred from keywords with both fields found; bot-authored issue
    titles are never changed because their creators may deduplicate by title.
    """
    plan = []
    for r in rows:
        if r["kind"] != "issue" or r["state"] != "open":
            continue
        cls = r["_cls"]
        labels = []
        if cls["type"]:
            labels.append("type:" + cls["type"])
        if cls["scopes"] and not cls["scopes"][0].startswith("~"):
            scope = cls["scopes"][0]
            fam = vocab.scope_family[scope]
            labels.append("family:" + fam)
            if scope != fam:
                labels.append("scope:" + scope)
        labels = [l for l in labels if l not in (r.get("labels") or [])]
        new_title = r["_suggest"]
        retitle = bool(new_title) and new_title != r["title"] and not is_bot(r["author"]) and r["_conf"] != "none"
        if not labels and not retitle:
            continue
        plan.append({
            "repo": r["repo"], "number": r["number"], "author": r["author"], "bot": is_bot(r["author"]),
            "title": r["title"], "new_title": new_title if retitle else None,
            "add_labels": labels, "confidence": r["_conf"],
            "type": cls["type"], "type_source": cls["type_source"],
            "scope": cls["scopes"][0] if cls["scopes"] else None, "scope_source": cls["scope_source"],
            "lint": sorted(set(f["code"] for f in r["_lint"])),
        })
    plan.sort(key=lambda p: (p["repo"], p["number"]))
    return plan


def write_csv(path, rows, fields):
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, lineterminator="\n", extrasaction="ignore")
        w.writeheader()
        for row in rows:
            w.writerow(row)


def keywords_md(inv, census):
    out = ["# Title taxonomy: keywords", "",
           "Grammar: `<type>(<scope>[,<scope>][ <qualifier>...])[!]: <subject>`, e.g. "
           "`fix(jade devops N12): census fails closed`.", "",
           "Pulse %s, vocabulary sha256 `%s`." % (census["pulse"]["fetched_at"], census["vocabulary_sha256"][:12]), "",
           "## Types", "", "| type | family | aliases | spellings seen |", "|---|---|---|---|"]
    for t in inv["types"]:
        seen = ", ".join("`%s` %d" % kv for kv in t["seen"].items())
        out.append("| `%s` | %s | %s | %s |" % (t["type"], t["family"], ", ".join(t["aliases"]) or "-", seen or "-"))
    out += ["", "## Families and scopes", "",
            "Aliases in *italics* only match inside an explicit `type(scope)` or a label, never free text.", ""]
    for fam in inv["families"]:
        n = sum(s["n_explicit"] for s in fam["scopes"])
        out += ["### %s (`%s`), %d explicit" % (fam["label"], fam["family"], n), "",
                "| scope | aliases | spellings seen | by repo |", "|---|---|---|---|"]
        for s in fam["scopes"]:
            aliases = ", ".join(("*%s*" % a) if a in s["explicit_only"] else a for a in s["aliases"])
            seen = ", ".join("`%s` %d" % kv for kv in s["seen"].items()) or "-"
            repos = ", ".join("%s %d" % kv for kv in s["by_repo"].items()) or "-"
            out.append("| `%s` | %s | %s | %s |" % (s["scope"], aliases, seen, repos))
        out.append("")
    out += ["## Qualifier classes", "", ", ".join("`%s`" % q for q in inv["qualifier_classes"]), "",
            "## Unmapped explicit scopes (add to a family or rename)", "", "| scope | n | by repo |", "|---|---|---|"]
    for u in inv["unmapped_scopes"]:
        out.append("| `%s` | %d | %s |" % (u["scope"], u["n"], ", ".join("%s %d" % kv for kv in u["by_repo"].items())))
    out += ["", "## Unknown types", "", "| type | n | by repo |", "|---|---|---|"]
    for u in inv["unknown_types"]:
        out.append("| `%s` | %d | %s |" % (u["type"], u["n"], ", ".join("%s %d" % kv for kv in u["by_repo"].items())))
    out += ["", "## Lint codes", "", "| code | severity | rule | n |", "|---|---|---|---|"]
    for code, c in inv["lint_codes"].items():
        out.append("| %s | %s | %s | %d |" % (code, c["severity"], c["message"], c["n"]))
    return "\n".join(out) + "\n"


def plan_md(plan):
    out = ["# Issue alignment plan (dry run)", "",
           "%d open issues: %d retitles, %d with label additions. Nothing has been changed on GitHub." % (
               len(plan), sum(1 for p in plan if p["new_title"]), sum(1 for p in plan if p["add_labels"])), "",
           "| issue | confidence | current title | proposed title | add labels |", "|---|---|---|---|---|"]
    for p in plan:
        esc = lambda s: (s or "").replace("|", "\\|")
        out.append("| %s#%d | %s | %s | %s | %s |" % (
            p["repo"], p["number"], p["confidence"], esc(p["title"]), esc(p["new_title"]) or "(keep)",
            ", ".join(p["add_labels"]) or "-"))
    return "\n".join(out) + "\n"


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/raw.json")
    ap.add_argument("--vocab", default=None)
    ap.add_argument("--out", default="out")
    ap.add_argument("--asof", default=None, help="YYYY-MM-DD for the 30-day windows (default: pulse date)")
    args = ap.parse_args(argv)

    with open(args.raw, encoding="utf-8") as fh:
        raw = json.load(fh)
    vocab = T.Vocabulary(args.vocab)
    with open(args.vocab or os.path.join(T.HERE, "vocabulary.json"), "rb") as fh:
        vocab_sha = hashlib.sha256(fh.read()).hexdigest()
    asof = datetime.strptime(args.asof or raw["fetched_at"][:10], "%Y-%m-%d") + timedelta(days=1)

    rows, stats, series, conformance = build(raw, vocab, asof)
    inv = inventory(rows, vocab)
    plan = issue_plan(rows, vocab)
    os.makedirs(args.out, exist_ok=True)

    census = {
        "schema": "gbogeb.title-taxonomy.census/1.0",
        "pulse": {"fetched_at": raw["fetched_at"], "owner": raw["owner"],
                  "repos": [{"repo": r["repo"], "head_sha": r["head_sha"], "default_branch": r["default_branch"],
                             "prs": sum(1 for x in r["rows"] if x["kind"] == "pr"),
                             "issues": sum(1 for x in r["rows"] if x["kind"] == "issue")} for r in raw["repos"]]},
        "vocabulary_sha256": vocab_sha,
        "levels": LEVELS,
        "conformance": [c for c in conformance if c["month"] == "ALL"],
        "stats": stats, "series": series, "inventory": inv,
        "issue_plan_summary": {"issues": len(plan), "retitles": sum(1 for p in plan if p["new_title"]),
                               "label_additions": sum(1 for p in plan if p["add_labels"])},
    }
    with open(os.path.join(args.out, "census.json"), "w", encoding="utf-8", newline="\n") as fh:
        json.dump(census, fh, ensure_ascii=False, indent=1)

    flat = []
    for r in rows:
        lv = T.levels(r, vocab)
        flat.append({
            "repo": r["repo"], "kind": r["kind"], "number": r["number"], "state": r["state"],
            "created": r["created"][:10], "closed": (r["closed"] or "")[:10], "author": r["author"],
            "title": r["title"], "type_family": lv["type_family"], "type": lv["type"],
            "type_source": r["_cls"]["type_source"], "family": lv["family"], "scope": lv["scope"],
            "scope_source": r["_cls"]["scope_source"], "prefix": lv["prefix"],
            "qualifiers": " ".join(q["token"] for q in r["_parsed"]["qualifiers"]),
            "confidence": r["_conf"], "lint": " ".join(sorted(set(f["code"] for f in r["_lint"]))),
            "suggested_title": r["_suggest"] or "",
        })
    for s in stats:
        s["id"] = "|".join([s["repo"], s["kind"], s["level"], s["key"]])
    for s in series:
        s["id"] = "|".join([s["repo"], s["kind"], s["level"], s["key"], s["month"]])
    for c in conformance:
        c["id"] = "|".join([c["repo"], c["kind"], c["month"]])
    write_csv(os.path.join(args.out, "rows.csv"), flat, list(flat[0].keys()))
    write_csv(os.path.join(args.out, "stats.csv"), stats, list(stats[0].keys()))
    write_csv(os.path.join(args.out, "timeseries.csv"), series, list(series[0].keys()))
    write_csv(os.path.join(args.out, "conformance.csv"), conformance, list(conformance[0].keys()))
    with open(os.path.join(args.out, "keywords.md"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(keywords_md(inv, census))
    with open(os.path.join(args.out, "issue_plan.json"), "w", encoding="utf-8", newline="\n") as fh:
        json.dump({"schema": "gbogeb.title-taxonomy.issue-plan/1.0", "pulse": raw["fetched_at"],
                   "vocabulary_sha256": vocab_sha, "items": plan}, fh, ensure_ascii=False, indent=1)
    with open(os.path.join(args.out, "issue_plan.md"), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(plan_md(plan))
    allc = [c for c in conformance if c["repo"] == "ALL" and c["month"] == "ALL"]
    for c in allc:
        print("ALL %-5s n=%-5d explicit=%.1f%% clean=%.1f%% resolved=%.1f%%" % (
            c["kind"], c["n"], 100 * c["explicit_rate"], 100 * c["clean_rate"], 100 * c["resolved_rate"]))
    print("issue plan: %(issues)d open issues, %(retitles)d retitles, %(label_additions)d label additions"
          % census["issue_plan_summary"])


if __name__ == "__main__":
    main()
