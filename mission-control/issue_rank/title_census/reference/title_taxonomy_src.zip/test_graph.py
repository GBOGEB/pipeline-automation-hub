"""python -m unittest test_graph"""
import unittest

import graph as G


def row(repo, kind, number, title="x", **extra):
    return dict({"repo": repo, "kind": kind, "number": number, "title": title}, **extra)


class EdgeTests(unittest.TestCase):
    def test_closing_reference_from_both_sides_is_one_edge(self):
        rows = [row("A", "pr", 2, closes=[{"repo": "A", "number": 1}]),
                row("A", "issue", 1, closed_by_refs=[{"repo": "A", "number": 2}])]
        es = G.edges(rows)
        self.assertEqual([(e["type"], e["src"], e["dst"]) for e in es], [("closes", "A/pr/2", "A/issue/1")])
        self.assertEqual(es[0]["evidence"], "closingIssuesReferences+closedByPullRequestsReferences")

    def test_cross_repo_close_and_parent(self):
        rows = [row("A", "pr", 5, closes=[{"repo": "B", "number": 9}]),
                row("B", "issue", 9, parent_ref={"repo": "B", "number": 3}),
                row("B", "issue", 3)]
        es = {(e["type"], e["src"], e["dst"], e["cross_repo"]) for e in G.edges(rows)}
        self.assertEqual(es, {("closes", "A/pr/5", "B/issue/9", True), ("parent", "B/issue/3", "B/issue/9", False)})

    def test_title_mentions_resolve_inside_pulse_only(self):
        rows = [row("A", "issue", 1, "[U6] Close #2 after B#7, see PR4 and #999"),
                row("A", "pr", 2), row("A", "pr", 4), row("B", "issue", 7)]
        es = sorted(e["dst"] for e in G.edges(rows))
        self.assertEqual(es, ["A/pr/2", "A/pr/4", "B/issue/7"])

    def test_old_pulse_without_refs(self):
        rows = [row("A", "pr", 2), row("A", "issue", 1, closed_by_prs=[2], parent=None)]
        self.assertEqual(len(G.edges(rows)), 1)


class BodyTests(unittest.TestCase):
    def test_body_refs_keywords_urls_and_code(self):
        body = ("Fixes #12 and closes GBOGEB/B#3.\nRefs ABACUS#2438, see https://github.com/GBOGEB/C/pull/77.\n"
                "Other/X#5 is someone else's. `#99` and ```\n#98\n``` are code. <!-- #97 -->")
        refs = {(r["repo"], r["number"], r["closing"]) for r in G.body_refs(body, "GBOGEB", "A")}
        self.assertEqual(refs, {("A", 12, True), ("B", 3, True), ("ABACUS", 2438, False), ("C", 77, False)})

    def test_body_and_timeline_edges_merge_by_strength(self):
        rows = [row("A", "pr", 2, body_refs=[{"repo": "A", "number": 1, "closing": True}]),
                row("A", "issue", 1, xrefs=[{"repo": "A", "number": 2, "will_close": False},
                                            {"repo": "a", "number": 3, "will_close": False}]),
                row("A", "issue", 3)]
        es = {(e["src"], e["dst"]): (e["type"], e["evidence"]) for e in G.edges(rows)}
        self.assertEqual(es[("A/pr/2", "A/issue/1")], ("closes", "body keyword+timeline"))
        self.assertEqual(es[("A/issue/3", "A/issue/1")], ("xref", "timeline"))

    def test_issue_body_closing_keyword_is_only_a_reference(self):
        rows = [row("A", "issue", 1, body_refs=[{"repo": "A", "number": 2, "closing": True}]), row("A", "issue", 2)]
        self.assertEqual(G.edges(rows)[0]["type"], "refs")


if __name__ == "__main__":
    unittest.main()
