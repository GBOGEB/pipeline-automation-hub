"""python -m unittest test_graph"""
import unittest

import graph as G


def row(repo, kind, number, title="x", **extra):
    return dict({"repo": repo, "kind": kind, "number": number, "title": title}, **extra)


class EdgeTests(unittest.TestCase):
    def test_closing_reference_from_both_sides_is_one_edge(self):
        rows = [row("A", "pr", 2, closes=[{"repo": "A", "number": 1}]),
                row("A", "issue", 1, closed_by_refs=[{"repo": "A", "number": 2}])]
        es = G.edges(rows)
        self.assertEqual([(e["type"], e["src"], e["dst"]) for e in es], [("closes", "A/pr/2", "A/issue/1")])

    def test_cross_repo_close_and_parent(self):
        rows = [row("A", "pr", 5, closes=[{"repo": "B", "number": 9}]),
                row("B", "issue", 9, parent_ref={"repo": "B", "number": 3}),
                row("B", "issue", 3)]
        es = {(e["type"], e["src"], e["dst"], e["cross_repo"]) for e in G.edges(rows)}
        self.assertEqual(es, {("closes", "A/pr/5", "B/issue/9", True), ("parent", "B/issue/3", "B/issue/9", False)})

    def test_title_mentions_resolve_inside_pulse_only(self):
        rows = [row("A", "issue", 1, "[U6] Close #2 after B#7, see PR4 and #999"),
                row("A", "pr", 2), row("A", "pr", 4), row("B", "issue", 7)]
        es = sorted(e["dst"] for e in G.edges(rows))
        self.assertEqual(es, ["A/pr/2", "A/pr/4", "B/issue/7"])

    def test_old_pulse_without_refs(self):
        rows = [row("A", "pr", 2), row("A", "issue", 1, closed_by_prs=[2], parent=None)]
        self.assertEqual(len(G.edges(rows)), 1)


if __name__ == "__main__":
    unittest.main()
